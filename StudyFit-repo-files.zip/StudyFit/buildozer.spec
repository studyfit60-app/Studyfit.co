[app]
title = Study Fit
package.name = studyfit
package.domain = co.studyfit
source.dir = .
source.include_exts = py,png,jpg,jpeg,ttf,json
source.exclude_dirs = bin,.buildozer,venv,__pycache__
version = 1.0.0
requirements = python3,kivy==2.3.0,plyer,certifi,pyjnius,android,sqlite3,openssl
icon.filename = assets/icon.png
presplash.filename = assets/presplash.png
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,POST_NOTIFICATIONS,VIBRATE
android.api = 34
android.minapi = 24
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
android.allow_backup = True

[buildozer]
log_level = 2
warn_on_root = 1
