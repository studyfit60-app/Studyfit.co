# -*- coding: utf-8 -*-
"""
=====================================================================
 STUDY FIT  -  SINGLE FILE APP  (main.py)
 Python + Kivy (Android UI) + Gemini + Firebase + SQLite + Razorpay
 The SAME file also contains the FastAPI backend:
     python main.py            -> runs the Kivy app (phone / desktop)
     python main.py --server   -> runs the backend (put it on a server)
=====================================================================

 >>> WHERE TO PUT YOUR KEYS / DETAILS  (search for "# >>>" in this file) <<<

  APP SIDE (CONFIG section just below)
    1. FIREBASE_API_KEY, FIREBASE_PROJECT_ID   (Firebase console > Project settings)
    2. BACKEND_URL                             (your deployed backend, https://...)
    3. GEMINI_API_KEY                          (ONLY for quick local testing, see note)
    4. PRIVACY_URL / TERMS_URL / SUPPORT_EMAIL

  SERVER SIDE (environment variables on your server, NEVER inside the APK)
    GEMINI_API_KEY            https://aistudio.google.com/apikey
    FIREBASE_API_KEY          same web API key as above
    RAZORPAY_KEY_ID           Razorpay dashboard > Settings > API Keys
    RAZORPAY_KEY_SECRET       (same place - secret, server only)
    RAZORPAY_WEBHOOK_SECRET   Razorpay dashboard > Webhooks (event: payment_link.paid)
    PUBLIC_BASE_URL           your server URL (used for the payment callback)
    GOOGLE_APPLICATION_CREDENTIALS  Firebase service-account json (phone OTP login)
    SMS provider keys         (MSG91 / Twilio / etc. - see send_sms())

 PAYMENT PROVIDER (India + UPI)  ->  RAZORPAY recommended
    UPI (GPay/PhonePe/Paytm), cards, netbanking, wallets, easy KYC, good docs.
    Alternatives: Cashfree, PhonePe PG, Paytm PG.
    IMPORTANT: Google Play requires Google Play Billing for *digital content*
    sold inside an Android app (your Rs.29 notes). Razorpay is fine for
    PHYSICAL products (store) and for a web/other-platform version. Before
    publishing on Play Store, move the notes purchase to Play Billing (or
    check Google's current policy for India alternatives).

 ASSETS (create folder  assets/  next to main.py and drop your files in)
    assets/logo.png            full original Study Fit logo (icon + text), transparent bg
    assets/logo_icon.png       icon-only version (small headers)
    assets/icon.png            launcher icon 512x512 (buildozer: icon.filename)
    assets/presplash.png       Android loading image (buildozer: presplash.filename)
    assets/google.png          Google "G" logo for login button
    assets/facebook.png        Facebook "f" logo for login button
    assets/avatar.png          default profile picture
    assets/products/<id>.png   store product images (id from STORE_PRODUCTS)
    assets/fonts/NotoSansDevanagari-Regular.ttf   (Hindi, Marathi)
    assets/fonts/NotoSansGujarati-Regular.ttf, NotoSansBengali-Regular.ttf,
                 NotoSansTamil-Regular.ttf, NotoSansTelugu-Regular.ttf,
                 NotoSansKannada-Regular.ttf, NotoSansMalayalam-Regular.ttf,
                 NotoSansGurmukhi-Regular.ttf       (download free from Google Fonts)
    If a file is missing the app shows a text fallback - it never crashes.

 buildozer.spec essentials (see the end of this file for a copy-paste block)
=====================================================================
"""
import os, sys, re, json, time, ssl, hmac, hashlib, sqlite3, threading, secrets
import datetime as dt
import urllib.request, urllib.error, urllib.parse

# =====================================================================
#  CONFIG
# =====================================================================
APP_NAME = "Study Fit"
APP_VERSION = "1.0.0"

# >>> 1. FIREBASE  (project "studyfitin")  -  web config from Firebase console > Project settings.
#     The web API key is a public identifier (safe inside the app); security comes from
#     Firestore rules + Authentication settings, not from hiding this key.
FIREBASE_WEB_CONFIG = {
    "apiKey": "AIzaSyA7hNUs0mm4V31_mjW4GVHG0lvlD3ldYTE",
    "authDomain": "studyfitin.firebaseapp.com",
    "projectId": "studyfitin",
    "storageBucket": "studyfitin.firebasestorage.app",
    "messagingSenderId": "1031928387831",
    "appId": "1:1031928387831:web:8b9c867d225fc9ea439bf2",
    "measurementId": "G-F9EKZVM12E",
}
FIREBASE_API_KEY = FIREBASE_WEB_CONFIG["apiKey"]
FIREBASE_PROJECT_ID = FIREBASE_WEB_CONFIG["projectId"]
#   Firebase console checklist (one time):
#     a) Authentication > Sign-in method: enable  Email/Password  and  Google
#     b) Authentication > Settings > Authorized domains: ADD your server domain
#        (e.g. studyfit-api.onrender.com)  <- Google login runs through a page on your server
#     c) Firestore Database: create database + paste the rules shown near fs_url() below

# >>> 2. YOUR BACKEND (this same file run with --server, deployed on Render/Railway/VPS)
#     Example: "https://studyfit-api.onrender.com"   (leave "" while only testing UI)
#     Needed for: Google login, AI routine/meals/workout (safe Gemini key), OTP, payments.
BACKEND_URL = ""
BACKEND_URL = BACKEND_URL.strip().rstrip("/")

# >>> 3. GEMINI API KEY  --  RECOMMENDED: put it on the SERVER as env var GEMINI_API_KEY.
#     For quick testing on your own phone only, you may paste it here and set
#     DEV_DIRECT_GEMINI = True. NEVER publish an APK with a key inside it
#     (anyone can extract it and burn your quota).
GEMINI_API_KEY = "PASTE_GEMINI_KEY_HERE"
DEV_DIRECT_GEMINI = True      # AI runs straight from the app. Before Play Store: set False + use BACKEND_URL
#     Models are tried in this order; if Google retires/limits one (404 / "model not found")
#     the next one is used automatically. Check the current names in Google AI Studio.
GEMINI_MODELS = ["gemini-3.8-flash", "gemini-3.6-flash", "gemini-2.5-flash"]

# >>> 4. LEGAL / SUPPORT
PRIVACY_URL = "https://example.com/privacy"      # >>> your Privacy Policy page
TERMS_URL = "https://example.com/terms"          # >>> your Terms page
SUPPORT_EMAIL = "support@example.com"            # >>> your support email

# >>> 5. PAID NOTES  (price is enforced again on the SERVER, never trust the app)
#     NOTES_ENABLED = False  ->  the Notes screen shows a clean "coming soon" page (no payment, no
#     buttons). Set it to True later when you have added CONTENT below.
NOTES_ENABLED = False
NOTES_PRICE_INR = 29

# >>> 6. STORE PRODUCTS (physical products only). Fill with real, legally sellable items.
#     category "supplement" is hidden automatically for users under 18.
STORE_PRODUCTS = [
    # {"id": "shaker01", "name": "Gym Shaker 700ml", "brand": "Your Brand", "price": 299,
    #  "category": "accessory", "desc": "BPA-free shaker bottle", "seller": "Seller name, GSTIN"},
]

# >>> 7. STUDY CONTENT  (verified / own / licensed content only - respect copyright)
#     CONTENT[class][subject] = {"chapters":[{"title":..., "free":bool, "notes":"text", "pyq":"text"}]}
#     Left empty on purpose: add your own content here or load it from Firestore.
SUBJECTS = {
    "10": ["Marathi", "Hindi", "English", "Mathematics Part 1 (Algebra)",
           "Mathematics Part 2 (Geometry)", "Science & Technology Part 1",
           "Science & Technology Part 2", "History & Political Science", "Geography"],
    "12": ["English", "Physics", "Chemistry", "Mathematics", "Biology"],
}
CONTENT = {"10": {}, "12": {}}

CATS = {"wake", "meal", "study", "revision", "homework", "school", "workout",
        "break", "water", "sleep", "rest", "winddown", "other"}
NOTIFY_CAT = {"study": "Study", "revision": "Study", "homework": "Study",
              "workout": "Fitness", "meal": "Diet", "water": "Diet"}

# =====================================================================
#  SHARED PURE-PYTHON LOGIC (used by BOTH the app and the server)
# =====================================================================
try:
    import certifi
    SSL_CTX = ssl.create_default_context(cafile=certifi.where())
except Exception:
    SSL_CTX = ssl.create_default_context()


class ApiError(Exception):
    def __init__(self, msg, code=0):
        super().__init__(msg)
        self.msg, self.code = msg, code


def http_json(method, url, body=None, headers=None, timeout=30):
    data = json.dumps(body).encode() if body is not None else None
    h = {"Content-Type": "application/json"}
    h.update(headers or {})
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=SSL_CTX) as r:
            raw = r.read().decode() or "{}"
            return json.loads(raw)
    except urllib.error.HTTPError as e:
        raw = e.read().decode(errors="ignore")
        try:
            j = json.loads(raw)
            m = j.get("error", {}).get("message") if isinstance(j.get("error"), dict) else None
            m = m or j.get("detail") or j.get("error") or raw
        except Exception:
            m = raw
        raise ApiError(str(m)[:300], e.code)
    except (urllib.error.URLError, TimeoutError, OSError):
        raise ApiError("NO_INTERNET", 0)


def parse_time(s):
    """'6:30', '06:30', '6:30 AM', '10 PM' -> minutes since midnight, else None.
    A plain int/float is taken as ALREADY-validated minutes (0..2879), so validated plans
    can safely be validated again (server -> app) without losing every item."""
    if s is None or isinstance(s, bool):
        return None
    if isinstance(s, (int, float)):
        return int(s) if 0 <= s < 2880 else None
    s = str(s).strip().upper().replace(".", ":")
    m = re.match(r"^(\d{1,2})(?::(\d{2}))?\s*(AM|PM)?$", s)
    if not m:
        return None
    h, mi, ap = int(m.group(1)), int(m.group(2) or 0), m.group(3)
    if mi > 59:
        return None
    if ap:
        if h < 1 or h > 12:
            return None
        h = h % 12 + (12 if ap == "PM" else 0)
    elif h > 23:
        return None
    return h * 60 + mi


def fmt_min(m):
    m = int(m) % 1440
    h, mi = divmod(m, 60)
    return "%d:%02d %s" % (h % 12 or 12, mi, "AM" if h < 12 else "PM")


def hhmm(m):
    m = int(m) % 1440
    return "%02d:%02d" % (m // 60, m % 60)


def parse_age(s):
    """'16' or '07-04-2009' -> (age, dob_iso|None)."""
    s = (s or "").strip()
    if s.isdigit():
        a = int(s)
        return (a, None) if 5 <= a <= 100 else (None, None)
    for f in ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d"):
        try:
            d = dt.datetime.strptime(s, f).date()
            t = dt.date.today()
            age = t.year - d.year - ((t.month, t.day) < (d.month, d.day))
            return (age, d.isoformat()) if 5 <= age <= 100 else (None, None)
        except ValueError:
            pass
    return None, None


# ---------------- prompts ----------------
SYSTEM_RULES = (
    "You are the planning engine of 'Study Fit', a student wellness planner. "
    "Reply with ONLY valid JSON that matches the requested schema (no markdown). "
    "Give general wellness and study guidance only - never medical advice or diagnosis. "
    "Never suggest supplements, fasting, extreme diets, calorie targets or aggressive exercise. "
    "If age_group is 'under_18', keep activity age-appropriate (no maximal lifting). "
    "Never decide meal size, calories or workout intensity from weight alone. "
    "Respect food allergies and food preference ABSOLUTELY. "
    "Use 24-hour HH:MM times. Never overlap activities. Respect fixed school times and sleep. "
    "If PROFILE.reply_language is given, write every human-readable text value (title, subject, note, "
    "summary) in that language; keep JSON keys, categories and HH:MM times in English/ASCII."
)


def prompt_routine(p):
    return (
        "TASK: Plan the student's day-by-day routine for EVERY date in PROFILE.dates.\nPROFILE: " +
        json.dumps(p, ensure_ascii=False) +
        "\nReturn JSON: {\"summary\":str(max 2 short sentences: what you planned and why),"
        "\"days\":[{\"date\":\"YYYY-MM-DD\",\"items\":[ITEM]}]} with one entry per date in PROFILE.dates, "
        "ITEM = {\"title\":str,\"category\":one of " + json.dumps(sorted(CATS - {"school", "sleep"})) +
        ",\"start\":\"HH:MM\",\"end\":\"HH:MM\",\"subject\":str,\"note\":str(max 100 chars, the reason)}.\n"
        "RULES:\n"
        "1. dates[i].school=true -> school/college runs school_start-school_end (do NOT add school yourself); "
        "study/revision/homework only after study_from. school=false -> free day, a little more study allowed.\n"
        "2. dates[i].busy = blocks already booked by the student: never overlap them. "
        "dates[i].from = the day is already running, plan only from that time and do NOT add a wake item.\n"
        "3. Study per day <= study_hours (minus dates[i].study_done_min if given); blocks <= 60 min with a "
        "10 min break; pick subjects by nearest exams, rotate subjects across the week, light revision the day "
        "before an exam, mention the exam in the note. Add homework time if pending_homework > 0.\n"
        "4. Include wake, meals (breakfast, lunch, snack, dinner at sensible times), water/rest/break, workout "
        "(ONLY if workout_minutes is present; <= workout_minutes, near workout_time, at least 1-2 rest days "
        "a week) and winddown. Stay between wake and sleep.\n"
        "5. PROFILE.note is the student's own request and has top priority (events, tiredness, new goals); "
        "apply it to the dates it talks about, but never break the safety rules or sleep time.\n"
        "6. Vary the days sensibly - do not copy the same day seven times."
    )


def prompt_meals(p):
    return (
        "TASK: Suggest practical Indian-style home meals using mainly the available ingredients.\nPROFILE: " +
        json.dumps(p) + "\nReturn JSON: {\"meals\":[{\"type\":\"breakfast|lunch|snack|dinner\",\"name\":str,"
        "\"items\":[str],\"time\":\"HH:MM\",\"note\":str}]} - one meal per type, simple and affordable."
    )


def prompt_workout(p):
    return (
        "TASK: Suggest one safe workout session.\nPROFILE: " + json.dumps(p) +
        "\nReturn JSON: {\"title\":str,\"exercises\":[{\"name\":str,\"minutes\":int,\"instruction\":str,"
        "\"caution\":str}]}. Total minutes <= workout_minutes. Use bodyweight/home options unless gym is chosen. "
        "Include warm-up and cool-down. Avoid anything unsafe for the given injuries."
    )


PROMPTS = {"routine": prompt_routine, "meals": prompt_meals, "workout": prompt_workout}


def _gemini_once(prompt, api_key, model, timeout):
    url = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent" % model
    body = {
        "systemInstruction": {"parts": [{"text": SYSTEM_RULES}]},
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"responseMimeType": "application/json", "temperature": 0.4,
                             "maxOutputTokens": 16384},
    }
    j = http_json("POST", url, body, {"x-goog-api-key": api_key}, timeout)
    try:
        parts = j["candidates"][0]["content"]["parts"]
        txt = "".join(str(x.get("text", "")) for x in parts if not x.get("thought"))
    except Exception:
        raise ApiError("AI_EMPTY", 502)
    txt = re.sub(r"^```(?:json)?|```$", "", txt.strip()).strip()
    if not txt:
        raise ApiError("AI_EMPTY", 502)
    try:
        return json.loads(txt)
    except Exception:
        raise ApiError("AI_BAD_JSON", 502)


def _model_gone(e):
    m = (e.msg or "").lower()
    return e.code == 404 or (e.code in (400, 403) and "model" in m and any(
        k in m for k in ("not found", "not supported", "no longer", "not available", "deprecated")))


def gemini_json(prompt, api_key, model=None, timeout=100):
    """Tries each model in GEMINI_MODELS; retries once on busy/garbled answers."""
    last = ApiError("AI_EMPTY", 502)
    for m in ([model] if model else list(GEMINI_MODELS)):
        for attempt in (0, 1):
            try:
                return _gemini_once(prompt, api_key, m, timeout)
            except ApiError as e:
                last = e
                if _model_gone(e):
                    break                                   # next model
                if e.code in (429, 500, 502, 503, 504) or e.msg in ("AI_EMPTY", "AI_BAD_JSON"):
                    if attempt == 0:
                        time.sleep(2)
                        continue
                    break
                raise                                       # bad key, bad request, no internet ...
    raise last


# ---------------- deterministic validation (AI is never the authority) ----------------
def validate_day(items, p, school_day, busy=None, earliest=None, study_used=0):
    """Deterministic referee for one day. busy = [{start,end,title}] already-booked blocks the plan must
    avoid; earliest = minutes - the day is already running, plan only from then on; study_used = study
    minutes already done today."""
    warns = []
    wake = parse_time(p.get("wake"))
    wake = 360 if wake is None else wake
    sleep = parse_time(p.get("sleep"))
    sleep = 1350 if sleep is None else sleep
    if sleep <= wake:
        sleep += 1440
    fixed = []
    ss, se = parse_time(p.get("school_start")), parse_time(p.get("school_end"))
    if school_day and ss is not None and se is not None and se > ss and (earliest is None or se > earliest):
        fixed.append(dict(title="School / College", category="school", start=ss, end=se,
                          subject="", note="Fixed commitment"))
    blocks = [(f["start"], f["end"]) for f in fixed]          # everything the plan must not overlap
    for b in busy or []:
        if isinstance(b, dict):
            bs, be = parse_time(b.get("start")), parse_time(b.get("end"))
            if bs is not None and be is not None and be > bs:
                blocks.append((bs, be))
    sf = parse_time(p.get("study_from"))
    try:
        budget = int(float(p.get("study_hours") or 3) * 60 * 1.1) - int(study_used or 0)
    except Exception:
        budget = 200
    budget = max(0, budget)
    try:
        wmin = max(10, int(p.get("workout_minutes") or 30))
    except Exception:
        wmin = 30
    out = []
    for it in items or []:
        if not isinstance(it, dict):
            continue
        title = str(it.get("title", "")).strip()[:60]
        cat = str(it.get("category", "other")).strip().lower()
        s, e = parse_time(it.get("start")), parse_time(it.get("end"))
        if not title or cat not in CATS or s is None or cat in ("school", "sleep"):
            continue
        if cat == "wake":
            s = wake
        if s < wake:
            if s + 1440 < sleep:
                s += 1440
            else:
                warns.append("Dropped '%s' (before wake-up)" % title)
                continue
        if e is None or e <= s:
            e = s + (20 if cat in ("meal", "break", "wake", "water", "rest") else 30)
        if e < s:
            e += 1440
        if earliest is not None:                  # day already running: keep only what is still ahead
            if cat == "wake" or e <= earliest:
                continue
            s = max(s, earliest)
        if cat in ("study", "revision", "homework") and school_day and sf is not None and s < sf:
            e += sf - s
            s = sf
        if cat in ("study", "revision"):
            e = min(e, s + 90)
        if cat == "workout":
            e = min(e, s + wmin)
        e = min(e, sleep)
        if e - s < 5 if cat == "wake" else e - s < 10:
            warns.append("Dropped '%s' (no time left)" % title)
            continue
        out.append(dict(title=title, category=cat, start=s, end=e,
                        subject=str(it.get("subject", ""))[:40], note=str(it.get("note", ""))[:140]))
    out.sort(key=lambda x: (x["start"], x["end"]))
    kept = []
    for it in out:  # never overlap fixed commitments / already-booked blocks
        if any(it["start"] < be and it["end"] > bs for bs, be in blocks):
            warns.append("Dropped '%s' (clashes with a booked time)" % it["title"])
            continue
        kept.append(it)
    final, STUDY = [], ("study", "revision")
    for it in kept:  # resolve overlaps + force 10 min break between study blocks
        if final:
            prev = final[-1]
            need = prev["end"] + (10 if (prev["category"] in STUDY and it["category"] in STUDY) else 0)
            if it["start"] < need:
                it["start"] = need
                if it["category"] == "wake":
                    continue
            if it["end"] - it["start"] < 10:
                warns.append("Dropped '%s' (overlap)" % it["title"])
                continue
        # skip if it now collides with fixed
        if any(it["start"] < be and it["end"] > bs for bs, be in blocks):
            warns.append("Dropped '%s' (clashes with a booked time)" % it["title"])
            continue
        final.append(it)
    used, trimmed = 0, []
    for it in final:  # study-hours budget
        if it["category"] in STUDY:
            d = it["end"] - it["start"]
            if used + d > budget:
                d = budget - used
                if d < 15:
                    warns.append("Dropped '%s' (daily study limit)" % it["title"])
                    continue
                it["end"] = it["start"] + d
            used += d
        trimmed.append(it)
    allv = sorted(fixed + trimmed, key=lambda x: x["start"])
    if earliest is None and not any(x["category"] == "wake" for x in allv):
        nxt = next((x["start"] for x in allv if x["start"] > wake), wake + 30)
        allv.insert(0, dict(title="Wake up & get ready", category="wake", start=wake,
                            end=max(wake + 5, min(wake + 30, nxt)), subject="", note=""))
    allv.append(dict(title="Sleep", category="sleep", start=sleep, end=sleep, subject="", note="Bedtime"))
    allv.sort(key=lambda x: (x["start"], x["end"]))
    if earliest is None and not any(x["category"] == "meal" for x in allv):
        warns.append("No meals were planned - add meals manually.")
    return allv, warns


def sanitize_items(items):
    """Cheap structural check for plans that come back over the network (already validated by the server)."""
    out = []
    for it in items if isinstance(items, list) else []:
        try:
            s, e, cat = int(it["start"]), int(it["end"]), str(it["category"])
            title = str(it["title"]).strip()[:60]
        except Exception:
            continue
        if not title or cat not in CATS or not (0 <= s < 2880) or e < s or e >= 2880:
            continue
        out.append(dict(title=title, category=cat, start=s, end=e,
                        subject=str(it.get("subject", ""))[:40], note=str(it.get("note", ""))[:140]))
    return out


def build_week(raw, p):
    """Gemini JSON ({"days":[{"date","items"}]}) + profile (with p["dates"]) -> validated plan
    {"days": {date: [items]}, "summary": str, "warnings": [str]}. The AI proposes, this code decides."""
    by_date = {}
    for d in (raw.get("days") if isinstance(raw, dict) else None) or []:
        if isinstance(d, dict) and isinstance(d.get("date"), str) and isinstance(d.get("items"), list):
            by_date[d["date"][:10]] = d["items"]
    days, warns, spare = {}, [], {}
    for d in p.get("dates") or []:
        key, school = str(d.get("date")), bool(d.get("school"))
        items = by_date.get(key)
        if items is None:
            items = spare.get(school)                         # AI skipped this date: reuse a same-type day
            if items is None:
                warns.append("AI did not plan %s" % key)
                days[key] = []
                continue
            warns.append("%s: reused a similar day" % key)
        else:
            spare.setdefault(school, items)
        fr = parse_time(d.get("from")) if d.get("from") else None
        try:
            used = int(d.get("study_done_min") or 0)
        except Exception:
            used = 0
        days[key], w = validate_day(items, p, school, busy=d.get("busy"), earliest=fr, study_used=used)
        warns += [("%s: %s" % (key[5:], x)) for x in w[:2]]
    summ = raw.get("summary") if isinstance(raw, dict) else ""
    return {"days": days, "summary": str(summ or "")[:240], "warnings": warns[:6]}


VEG_BAD = ["chicken", "mutton", "fish", "egg", "beef", "pork", "prawn", "meat", "keema"]
VEGAN_BAD = VEG_BAD + ["milk", "paneer", "curd", "dahi", "ghee", "butter", "cheese", "honey", "yogurt", "lassi", "khoa"]
BAD_WORDS = ["steroid", "supplement", "creatine", "fasting", "starve", "one-rep max", "1rm", "protein powder"]


def _allergy_tokens(p):
    return [t for t in re.split(r"[,;/\n ]+", str(p.get("allergies", "")).lower()) if len(t) >= 3]


def validate_meals(data, p):
    out, warns = [], []
    pref = str(p.get("food_pref", "")).lower()
    bad = VEGAN_BAD if "vegan" in pref else VEG_BAD if "vegetarian" in pref and "non" not in pref else []
    al = _allergy_tokens(p)
    for m in (data or {}).get("meals", []) if isinstance(data, dict) else []:
        if not isinstance(m, dict):
            continue
        typ = str(m.get("type", "")).lower()
        if typ not in ("breakfast", "lunch", "snack", "dinner"):
            continue
        items = [str(x)[:40] for x in (m.get("items") or [])][:10]
        txt = (str(m.get("name", "")) + " " + " ".join(items)).lower()
        if any(a in txt for a in al):
            warns.append("Removed %s (allergy conflict)" % typ)
            continue
        if any(b in txt for b in bad):
            warns.append("Removed %s (food preference conflict)" % typ)
            continue
        tm = parse_time(m.get("time"))
        out.append(dict(type=typ, name=str(m.get("name", ""))[:60], items=items,
                        time=hhmm(tm) if tm is not None else "", note=str(m.get("note", ""))[:140]))
    return {"meals": out, "warnings": warns}


def validate_workout(data, p):
    try:
        cap = max(10, int(p.get("workout_minutes") or 30))
    except Exception:
        cap = 30
    out, total, warns = [], 0, []
    ex = (data or {}).get("exercises", []) if isinstance(data, dict) else []
    for e in ex[:10]:
        if not isinstance(e, dict):
            continue
        txt = json.dumps(e).lower()
        if any(b in txt for b in BAD_WORDS):
            warns.append("Removed an unsafe item")
            continue
        try:
            mins = max(1, min(int(e.get("minutes", 5)), 30))
        except Exception:
            mins = 5
        if total + mins > cap:
            mins = cap - total
            if mins < 2:
                break
        total += mins
        out.append(dict(name=str(e.get("name", ""))[:50], minutes=mins,
                        instruction=str(e.get("instruction", ""))[:240], caution=str(e.get("caution", ""))[:140]))
    return {"title": str((data or {}).get("title", "Workout"))[:50] if isinstance(data, dict) else "Workout",
            "exercises": out, "minutes": total, "warnings": warns}


def run_ai(kind, payload, api_key):
    """Prompt -> Gemini -> deterministic validation. Same code on app (dev) and server."""
    if kind not in PROMPTS:
        raise ApiError("BAD_KIND", 400)
    p = payload.get("profile", {})
    raw = gemini_json(PROMPTS[kind](p), api_key)
    if kind == "routine":
        return build_week(raw, p)
    if kind == "meals":
        return validate_meals(raw, p)
    return validate_workout(raw, p)


# ---------------- Google / Facebook login through a page on YOUR server ----------------
#  Kivy cannot show Google's account picker natively, so the app opens  BACKEND_URL/auth/google?sid=XYZ
#  in the phone browser. That page signs in with the Firebase web SDK (config above), sends the Firebase
#  tokens to the server under the one-time id "sid", and the app (which polls with the same sid) picks
#  them up. No SHA-1 / google-services.json / native SDK needed.
SID_RE = re.compile(r"^[A-Za-z0-9_-]{20,64}$")


class AuthBox:
    """Holds a finished browser login for a few minutes until the app collects it (one time only)."""

    def __init__(self, ttl=300, cap=2000):
        self.ttl, self.cap, self.d, self.lk = ttl, cap, {}, threading.Lock()

    def _gc(self):
        now = time.time()
        for k in [k for k, (exp, _) in self.d.items() if exp < now]:
            self.d.pop(k, None)
        while len(self.d) > self.cap:
            self.d.pop(next(iter(self.d)))

    def put(self, sid, data):
        with self.lk:
            self._gc()
            self.d[sid] = (time.time() + self.ttl, data)

    def pop(self, sid):
        with self.lk:
            self._gc()
            v = self.d.pop(sid, None)
        return v[1] if v else None


LOGIN_PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Study Fit - Sign in</title>
<style>
body{margin:0;font-family:system-ui,Roboto,Arial,sans-serif;background:#081226;color:#fff;display:flex;
min-height:100vh;align-items:center;justify-content:center}
.c{width:min(92vw,380px);background:#0f1f3d;border:1px solid #1f4fa8;border-radius:18px;padding:26px;text-align:center}
h1{font-size:24px;margin:0 0 8px}p{color:#9fb2d1;font-size:14px;line-height:1.5;margin:0}
button{width:100%;padding:14px;border:0;border-radius:12px;font-size:16px;font-weight:700;color:#fff;
background:linear-gradient(90deg,#1a73ff,#33d98a);margin-top:18px}
button:disabled{opacity:.6}#msg{margin-top:14px;font-size:14px;line-height:1.5}.ok{color:#33d98a}.err{color:#ff6b6b}
</style></head><body><div class="c">
<h1>Study <span style="color:#33d98a">Fit</span></h1>
<p id="info">Sign in with __NAME__. Continue only if you just started this from the Study Fit app.</p>
<button id="go">Continue with __NAME__</button><div id="msg"></div></div>
<script type="module">
import {initializeApp} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {getAuth,GoogleAuthProvider,FacebookAuthProvider,signInWithPopup,signInWithRedirect,getRedirectResult}
from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
const SID="__SID__",PROVIDER="__PROVIDER__",NAME="__NAME__";
const auth=getAuth(initializeApp(__CFG__));
const prov=PROVIDER==="google"?new GoogleAuthProvider():new FacebookAuthProvider();
if(PROVIDER==="google")prov.setCustomParameters({prompt:"select_account"});
const msg=document.getElementById("msg"),go=document.getElementById("go"),info=document.getElementById("info");
function say(t,c){msg.textContent=t;msg.className=c||"";}
async function finish(user){
  say("Finishing sign-in...");
  const idToken=await user.getIdToken();
  const r=await fetch("/auth/complete",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({sid:SID,idToken:idToken,refreshToken:user.refreshToken,expiresIn:"3600"})});
  if(!r.ok)throw new Error("Server rejected the login ("+r.status+")");
  go.style.display="none";info.textContent="";
  say("Signed in as "+(user.email||"your account")+". You can close this page and go back to the Study Fit app.","ok");
}
function fail(e){
  const c=e&&e.code;go.disabled=false;
  if(c==="auth/popup-closed-by-user"||c==="auth/cancelled-popup-request")say("Sign-in cancelled. Tap the button to try again.","err");
  else if(c==="auth/unauthorized-domain")say("This server's domain is not authorised in Firebase: Authentication > Settings > Authorized domains.","err");
  else if(c==="auth/operation-not-allowed")say(NAME+" sign-in is not enabled in Firebase: Authentication > Sign-in method.","err");
  else say("Sign-in failed: "+((e&&(e.message||e.code))||e),"err");
}
go.addEventListener("click",async()=>{
  go.disabled=true;say("Opening "+NAME+"...");
  try{const res=await signInWithPopup(auth,prov);await finish(res.user);}
  catch(e){
    if(e&&(e.code==="auth/popup-blocked"||e.code==="auth/operation-not-supported-in-this-environment")){
      try{await signInWithRedirect(auth,prov);return;}catch(e2){return fail(e2);}}
    fail(e);}
});
getRedirectResult(auth).then(async res=>{if(res&&res.user){go.disabled=true;await finish(res.user);}}).catch(fail);
</script></body></html>"""


def login_page_html(provider, sid):
    name = "Google" if provider == "google" else "Facebook"
    return (LOGIN_PAGE.replace("__CFG__", json.dumps(FIREBASE_WEB_CONFIG)).replace("__PROVIDER__", provider)
            .replace("__NAME__", name).replace("__SID__", sid))


# =====================================================================
#  BACKEND (FastAPI)  ->  python main.py --server
#  pip install fastapi uvicorn   (+ firebase_admin for phone OTP login)
# =====================================================================
def run_server():
    from fastapi import FastAPI, Header, HTTPException, Request
    from fastapi.responses import HTMLResponse
    import uvicorn

    E = os.environ.get
    GKEY = E("GEMINI_API_KEY") or GEMINI_API_KEY             # >>> env var on server
    FBKEY = E("FIREBASE_API_KEY") or FIREBASE_API_KEY
    RZP_ID, RZP_SECRET = E("RAZORPAY_KEY_ID", ""), E("RAZORPAY_KEY_SECRET", "")  # >>> Razorpay keys
    RZP_WH = E("RAZORPAY_WEBHOOK_SECRET", "")
    BASE = E("PUBLIC_BASE_URL", "")
    DEV_PRINT_OTP = E("DEV_PRINT_OTP") == "1"                # testing only: prints OTP in server log

    db = sqlite3.connect(E("PAY_DB", "server_payments.db"), check_same_thread=False)
    db.execute("CREATE TABLE IF NOT EXISTS pay(id TEXT PRIMARY KEY,uid TEXT,kind TEXT,ref TEXT,"
               "amount INT,status TEXT,ts INT)")
    db.commit()
    lock = threading.Lock()
    app = FastAPI(title="Study Fit API")
    rate, otps = {}, {}
    authbox = AuthBox()

    def limit(key, n, per):
        now = time.time()
        with lock:
            if len(rate) > 5000:                               # keep memory bounded
                for k in [k for k, v in rate.items() if not v or now - v[-1] > 3600]:
                    rate.pop(k, None)
            q = [t for t in rate.get(key, []) if now - t < per]
            if len(q) >= n:
                raise HTTPException(429, "Too many requests, try later")
            q.append(now)
            rate[key] = q

    def uid_of(auth):
        if not auth or not auth.lower().startswith("bearer "):
            raise HTTPException(401, "Login required")
        try:
            j = http_json("POST", "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=" + FBKEY,
                          {"idToken": auth.split(" ", 1)[1]})
            return j["users"][0]["localId"]
        except Exception:
            raise HTTPException(401, "Invalid session")

    @app.get("/health")
    def health():
        return {"ok": True}

    # ---------- AI ----------
    @app.post("/ai/{kind}")
    def ai(kind: str, payload: dict, authorization: str = Header(None)):
        uid = uid_of(authorization)
        limit("ai:" + uid, 20, 3600)
        if not GKEY:
            raise HTTPException(503, "Gemini key not configured on server")
        if len(json.dumps(payload)) > 40000:
            raise HTTPException(413, "Payload too large")
        try:
            return run_ai(kind, payload, GKEY)
        except ApiError as e:
            raise HTTPException(e.code if 400 <= e.code < 600 else 502, e.msg)

    # ---------- PAYMENTS (Razorpay Payment Links: UPI/cards/netbanking) ----------
    def rzp(method, path, body=None):
        if not (RZP_ID and RZP_SECRET):
            raise HTTPException(503, "Razorpay keys not configured")
        import base64
        tok = base64.b64encode(("%s:%s" % (RZP_ID, RZP_SECRET)).encode()).decode()
        return http_json(method, "https://api.razorpay.com/v1" + path, body, {"Authorization": "Basic " + tok})

    def price_of(kind, ref):
        if kind == "notes":
            return NOTES_PRICE_INR
        if kind == "product":
            for pr in STORE_PRODUCTS:
                if pr["id"] == ref:
                    return int(pr["price"])
        raise HTTPException(400, "Unknown item")

    @app.post("/pay/create-link")
    def pay_create(payload: dict, authorization: str = Header(None)):
        uid = uid_of(authorization)
        limit("pay:" + uid, 10, 3600)
        kind, ref = str(payload.get("kind")), str(payload.get("ref"))[:60]
        amount = price_of(kind, ref)                         # price decided by SERVER only
        rid = "sf" + secrets.token_hex(8)
        body = {"amount": amount * 100, "currency": "INR", "reference_id": rid,
                "description": str(payload.get("desc", "Study Fit"))[:100],
                "notify": {"sms": False, "email": False}, "notes": {"uid": uid, "kind": kind, "ref": ref}}
        if BASE:
            body["callback_url"] = BASE + "/pay/thanks"
            body["callback_method"] = "get"
        r = rzp("POST", "/payment_links", body)
        with lock:
            db.execute("INSERT INTO pay VALUES(?,?,?,?,?,?,?)",
                       (r["id"], uid, kind, ref, amount, "created", int(time.time())))
            db.commit()
        return {"id": r["id"], "url": r["short_url"], "amount": amount}

    def mark_paid(pid):
        with lock:
            db.execute("UPDATE pay SET status='paid' WHERE id=?", (pid,))
            db.commit()

    @app.post("/pay/status")
    def pay_status(payload: dict, authorization: str = Header(None)):
        uid = uid_of(authorization)
        pid = str(payload.get("id"))
        row = db.execute("SELECT uid,status,kind,ref,amount FROM pay WHERE id=?", (pid,)).fetchone()
        if not row or row[0] != uid:
            raise HTTPException(404, "Payment not found")
        if row[1] != "paid":
            if rzp("GET", "/payment_links/" + pid).get("status") == "paid":   # verified with Razorpay itself
                mark_paid(pid)
                return {"paid": True, "kind": row[2], "ref": row[3], "amount": row[4]}
            return {"paid": False}
        return {"paid": True, "kind": row[2], "ref": row[3], "amount": row[4]}

    @app.get("/pay/my")
    def pay_my(authorization: str = Header(None)):
        uid = uid_of(authorization)
        rows = db.execute("SELECT id,kind,ref,amount FROM pay WHERE uid=? AND status='paid'", (uid,)).fetchall()
        return {"items": [dict(id=r[0], kind=r[1], ref=r[2], amount=r[3]) for r in rows]}

    @app.post("/pay/webhook")
    async def pay_webhook(request: Request):
        raw = await request.body()
        sig = request.headers.get("X-Razorpay-Signature", "")
        good = hmac.new(RZP_WH.encode(), raw, hashlib.sha256).hexdigest()
        if not RZP_WH or not hmac.compare_digest(good, sig):
            raise HTTPException(400, "bad signature")
        ev = json.loads(raw)
        if ev.get("event") == "payment_link.paid":
            mark_paid(ev["payload"]["payment_link"]["entity"]["id"])
        return {"ok": True}

    @app.get("/pay/thanks")
    def pay_thanks():
        return {"message": "Payment received. Go back to Study Fit and tap 'Check payment status'."}

    # ---------- OTP (mobile) ----------
    def send_sms(phone, text):
        # >>> PUT YOUR SMS PROVIDER HERE (MSG91 / Twilio / Fast2SMS ...). India needs DLT-registered
        #     templates for SMS. Implement the provider's REST call here using its docs.
        if DEV_PRINT_OTP:
            print("DEV OTP for", phone, ":", text)
            return
        raise HTTPException(501, "SMS provider not configured (see send_sms in main.py)")

    @app.post("/otp/send")
    def otp_send(payload: dict):
        phone = str(payload.get("phone", "")).strip()
        if not re.match(r"^\+\d{10,14}$", phone):
            raise HTTPException(400, "Use format +91XXXXXXXXXX")
        limit("otp:" + phone, 3, 600)
        code = "%06d" % secrets.randbelow(1000000)
        with lock:
            otps[phone] = dict(h=hashlib.sha256(code.encode()).hexdigest(), exp=time.time() + 300, tries=0)
        send_sms(phone, "Your Study Fit code is %s. Valid for 5 minutes." % code)
        return {"sent": True}

    @app.post("/otp/verify")
    def otp_verify(payload: dict, authorization: str = Header(None)):
        phone, code = str(payload.get("phone", "")).strip(), str(payload.get("code", "")).strip()
        with lock:
            o = otps.get(phone)
            if not o or o["exp"] < time.time() or o["tries"] >= 5:
                raise HTTPException(400, "OTP expired or too many attempts")
            o["tries"] += 1
            ok = hmac.compare_digest(o["h"], hashlib.sha256(code.encode()).hexdigest())
            if ok:
                otps.pop(phone, None)
        if not ok:
            raise HTTPException(400, "Wrong OTP")
        try:
            import firebase_admin
            from firebase_admin import auth as fa
            if not firebase_admin._apps:
                firebase_admin.initialize_app()          # uses GOOGLE_APPLICATION_CREDENTIALS
        except Exception:
            raise HTTPException(501, "firebase_admin not configured on server")
        if authorization:                                # link phone to the logged-in account
            uid = uid_of(authorization)
            fa.update_user(uid, phone_number=phone)
            return {"linked": True}
        try:
            user = fa.get_user_by_phone_number(phone)
        except Exception:
            user = fa.create_user(phone_number=phone)
        return {"customToken": fa.create_custom_token(user.uid).decode()}

    # ---------- GOOGLE / FACEBOOK LOGIN (browser page + one-time hand-over to the app) ----------
    @app.get("/auth/{provider}", response_class=HTMLResponse)
    def auth_page(provider: str, sid: str = ""):
        if provider not in ("google", "facebook") or not SID_RE.match(sid):
            raise HTTPException(400, "Bad login link - start again from the Study Fit app")
        return HTMLResponse(login_page_html(provider, sid), headers={"Cache-Control": "no-store"})

    @app.post("/auth/complete")
    def auth_complete(payload: dict):
        sid, tok = str(payload.get("sid", "")), str(payload.get("idToken", ""))
        if not SID_RE.match(sid) or not tok:
            raise HTTPException(400, "Bad request")
        limit("authc:" + sid, 5, 300)
        try:                                                     # Firebase itself verifies the token
            u = http_json("POST", "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=" + FBKEY,
                          {"idToken": tok})["users"][0]
        except Exception:
            raise HTTPException(401, "Invalid login")
        authbox.put(sid, dict(localId=u["localId"], email=u.get("email", ""), displayName=u.get("displayName", ""),
                              idToken=tok, refreshToken=str(payload.get("refreshToken", ""))[:2000],
                              expiresIn=str(payload.get("expiresIn", "3600"))[:6]))
        return {"ok": True}

    @app.post("/auth/poll")
    def auth_poll(payload: dict):
        sid = str(payload.get("sid", ""))
        if not SID_RE.match(sid):
            raise HTTPException(400, "Bad request")
        limit("authp:" + sid, 150, 300)
        r = authbox.pop(sid)
        return {"status": "done", "result": r} if r else {"status": "pending"}

    uvicorn.run(app, host="0.0.0.0", port=int(E("PORT", "8000")))


if __name__ == "__main__" and "--server" in sys.argv:
    run_server()
    sys.exit(0)

# =====================================================================
#  KIVY APP  (everything below runs on the phone)
# =====================================================================
os.environ.setdefault("KIVY_NO_ARGS", "1")
import webbrowser
from kivy.app import App
from kivy.clock import Clock
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.graphics import Color, RoundedRectangle, Line, Rectangle
from kivy.graphics.texture import Texture
from kivy.metrics import dp, sp
from kivy.properties import NumericProperty
from kivy.uix.behaviors import ButtonBehavior, ToggleButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.modalview import ModalView
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.scrollview import ScrollView
from kivy.uix.switch import Switch
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from kivy.utils import platform

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP = None  # running app instance

LANGS = [("en", "English"), ("hi", "हिंदी"), ("mr", "मराठी"), ("gu", "ગુજરાતી"), ("bn", "বাংলা"),
         ("ta", "தமிழ்"), ("te", "తెలుగు"), ("kn", "ಕನ್ನಡ"), ("ml", "മലയാളം"), ("pa", "ਪੰਜਾਬੀ")]
LANG_FONT = {"hi": "NotoSansDevanagari-Regular.ttf", "mr": "NotoSansDevanagari-Regular.ttf",
             "gu": "NotoSansGujarati-Regular.ttf", "bn": "NotoSansBengali-Regular.ttf",
             "ta": "NotoSansTamil-Regular.ttf", "te": "NotoSansTelugu-Regular.ttf",
             "kn": "NotoSansKannada-Regular.ttf", "ml": "NotoSansMalayalam-Regular.ttf",
             "pa": "NotoSansGurmukhi-Regular.ttf"}
_FONTS = {}
LANG_EN = {"en": "English", "hi": "Hindi", "mr": "Marathi", "gu": "Gujarati", "bn": "Bengali", "ta": "Tamil",
           "te": "Telugu", "kn": "Kannada", "ml": "Malayalam", "pa": "Punjabi"}


def lang_name(code):
    """Native name only when its font is installed (otherwise the glyphs show as empty boxes)."""
    native = dict(LANGS).get(code)
    if code == "en" or ("F_" + code) in _FONTS:
        return native or LANG_EN.get(code, "English")
    return LANG_EN.get(code, "English")


def lang_options():
    """-> ([(code, label)], {code: font}) for the language chips."""
    return [(c, lang_name(c)) for c, _ in LANGS], {c: "F_" + c for c, _ in LANGS if ("F_" + c) in _FONTS}


def open_url(url):
    """Open a link / mailto in the phone's browser or mail app."""
    if platform == "android":
        try:
            from jnius import autoclass
            Intent, Uri = autoclass("android.content.Intent"), autoclass("android.net.Uri")
            act = autoclass("org.kivy.android.PythonActivity").mActivity
            act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            return True
        except Exception:
            pass
    try:
        return webbrowser.open(url)
    except Exception:
        return False


# >>> TRANSLATIONS: key = English text used in t("..."). Add gu/bn/ta/te/kn/ml/pa the same way.
#     Anything missing falls back to English automatically.
TR = {
    "hi": {"Login": "लॉगिन", "Create Account": "खाता बनाएं", "Continue": "आगे बढ़ें", "Next": "आगे",
           "Skip for Now": "अभी छोड़ें", "Welcome Back!": "वापसी पर स्वागत है!", "Home": "होम",
           "Study": "पढ़ाई", "Fitness": "फिटनेस", "Diet": "आहार", "Profile": "प्रोफ़ाइल",
           "Settings": "सेटिंग्स", "Today": "आज", "Weekly": "साप्ताहिक", "Exams": "परीक्षा",
           "Generate My AI Routine": "मेरा AI रूटीन बनाएं", "Regenerate Routine": "रूटीन फिर बनाएं",
           "Save": "सेव करें", "Cancel": "रद्द करें", "Log Out": "लॉग आउट", "Notifications": "सूचनाएं",
           "Progress": "प्रगति", "Good Morning": "सुप्रभात", "Good Afternoon": "नमस्कार",
           "Good Evening": "शुभ संध्या", "Daily Routine": "दैनिक रूटीन", "Workout Plan": "वर्कआउट प्लान",
           "Diet Planner": "डाइट प्लानर", "Study Planner": "स्टडी प्लानर", "Finish Setup": "सेटअप पूरा करें",
           "Sync Now": "अभी सिंक करें", "Delete Account": "खाता हटाएं", "Password": "पासवर्ड",
           "Forgot Password?": "पासवर्ड भूल गए?", "Continue with Google": "Google से जारी रखें",
           "Continue with Facebook": "Facebook से जारी रखें", "Select Language": "भाषा चुनें",
           "Water Intake": "पानी का सेवन"},
    "mr": {"Login": "लॉगिन", "Create Account": "खाते तयार करा", "Continue": "पुढे जा", "Next": "पुढे",
           "Skip for Now": "आत्ता वगळा", "Welcome Back!": "पुन्हा स्वागत!", "Home": "होम",
           "Study": "अभ्यास", "Fitness": "फिटनेस", "Diet": "आहार", "Profile": "प्रोफाइल",
           "Settings": "सेटिंग्ज", "Today": "आज", "Weekly": "साप्ताहिक", "Exams": "परीक्षा",
           "Generate My AI Routine": "माझे AI रुटीन तयार करा", "Regenerate Routine": "रुटीन पुन्हा तयार करा",
           "Save": "जतन करा", "Cancel": "रद्द करा", "Log Out": "लॉग आउट", "Notifications": "सूचना",
           "Progress": "प्रगती", "Good Morning": "सुप्रभात", "Good Afternoon": "नमस्कार",
           "Good Evening": "शुभ संध्याकाळ", "Daily Routine": "दैनिक रुटीन", "Workout Plan": "वर्कआउट प्लॅन",
           "Diet Planner": "डायट प्लॅनर", "Study Planner": "स्टडी प्लॅनर", "Finish Setup": "सेटअप पूर्ण करा",
           "Sync Now": "आता सिंक करा", "Delete Account": "खाते हटवा", "Password": "पासवर्ड",
           "Forgot Password?": "पासवर्ड विसरलात?", "Continue with Google": "Google सह सुरू ठेवा",
           "Continue with Facebook": "Facebook सह सुरू ठेवा", "Select Language": "भाषा निवडा",
           "Water Intake": "पाण्याचे सेवन"},
}


def t(s):
    lang = APP.prof.get("lang", "en") if APP else "en"
    return TR.get(lang, {}).get(s, s)


def cur_font():
    lang = APP.prof.get("lang", "en") if APP else "en"
    return "F_" + lang if ("F_" + lang) in _FONTS else "Roboto"


def register_fonts():
    for lang, fn in LANG_FONT.items():
        p = os.path.join(BASE_DIR, "assets", "fonts", fn)
        if os.path.exists(p):
            LabelBase.register(name="F_" + lang, fn_regular=p)
            _FONTS["F_" + lang] = p


def asset(name):
    p = os.path.join(BASE_DIR, "assets", name)
    return p if os.path.exists(p) else None


# ---------------- theme ----------------
T = {}
DARK = dict(bg=(.03, .07, .15, 1), card=(.06, .12, .24, 1), card2=(.09, .18, .33, 1), field=(.05, .10, .20, 1),
            text=(1, 1, 1, 1), sub=(.62, .70, .82, 1), accent=(.13, .52, 1, 1), green=(.20, .85, .50, 1),
            border=(.15, .42, .85, .55), danger=(1, .38, .38, 1))
LIGHT = dict(bg=(.94, .97, 1, 1), card=(1, 1, 1, 1), card2=(.88, .93, 1, 1), field=(.96, .98, 1, 1),
             text=(.05, .10, .20, 1), sub=(.36, .43, .55, 1), accent=(.10, .42, .95, 1), green=(.10, .65, .35, 1),
             border=(.55, .70, .95, .8), danger=(.85, .2, .2, 1))


def set_theme(dark=True):
    T.clear()
    T.update(DARK if dark else LIGHT)
    Window.clearcolor = T["bg"]


_GR = {}


def get_grad(k):
    if k not in _GR:
        c1, c2 = ((.10, .45, 1, 1), (.20, .85, .50, 1)) if k == "grad" else ((.10, .38, 1, 1), (.22, .62, 1, 1))
        tex = Texture.create(size=(2, 1), colorfmt="rgba")
        tex.blit_buffer(bytes(int(v * 255) for v in (*c1, *c2)), colorfmt="rgba", bufferfmt="ubyte")
        tex.mag_filter = "linear"
        _GR[k] = tex
    return _GR[k]


# ---------------- small widgets ----------------
class L(Label):
    def __init__(self, text="", sz=14, col="text", bold=False, center=False, **kw):
        kw.setdefault("markup", False)
        super().__init__(text=text, font_size=sp(sz), color=T[col], bold=bold, size_hint_y=None,
                         halign="center" if center else "left", valign="middle", font_name=cur_font(), **kw)
        self.bind(width=lambda *_: setattr(self, "text_size", (self.width, None)))
        self.bind(texture_size=lambda *_: setattr(self, "height", self.texture_size[1] + dp(2)))


def vbox(sp_=10, fixed=False):
    b = BoxLayout(orientation="vertical", spacing=dp(sp_), size_hint_y=None if not fixed else 1)
    if not fixed:
        b.bind(minimum_height=b.setter("height"))
    return b


def hrow(h=48, *ws, spacing=8):
    r = BoxLayout(size_hint_y=None, height=dp(h), spacing=dp(spacing))
    for w in ws:
        if w.size_hint_y is None:
            w.pos_hint = {"center_y": .5}
        r.add_widget(w)
    return r


def arow(*ws, min_h=30, spacing=8):
    """Row whose height follows its tallest label (so wrapped text never overlaps the next row)."""
    r = BoxLayout(size_hint_y=None, height=dp(min_h), spacing=dp(spacing))

    def fit(*_):
        r.height = max([dp(min_h)] + [w.height for w in r.children if w.size_hint_y is None])
    for w in ws:
        if w.size_hint_y is None:
            w.pos_hint = {"center_y": .5}
            w.bind(height=fit)
        r.add_widget(w)
    fit()
    return r


def gap(h=8):
    return Widget(size_hint_y=None, height=dp(h))


class Card(BoxLayout):
    def __init__(self, pad=14, spacing=8, col="card", **kw):
        super().__init__(orientation="vertical", size_hint_y=None, padding=dp(pad), spacing=dp(spacing), **kw)
        self.bind(minimum_height=self.setter("height"))
        with self.canvas.before:
            Color(*T[col])
            self._r = RoundedRectangle(radius=[dp(16)])
            Color(*T["border"])
            self._l = Line(width=1)
        self.bind(pos=self._u, size=self._u)

    def _u(self, *_):
        self._r.pos, self._r.size = self.pos, self.size
        self._l.rounded_rectangle = (self.x, self.y, self.width, self.height, dp(16))


class TapCard(ButtonBehavior, Card):
    pass


class GButton(ButtonBehavior, Label):
    def __init__(self, text="", kind="grad", h=48, **kw):
        light = kind in ("grad", "blue", "danger")
        kw.setdefault("font_size", sp(15))          # callers may pass their own size (nav bar, quick actions)
        super().__init__(text=text, size_hint_y=None, height=dp(h), bold=True,
                         font_name=cur_font(), color=(1, 1, 1, 1) if light else T["text"],
                         halign="center", valign="middle", **kw)
        self.bind(size=lambda *_: setattr(self, "text_size", (self.width - dp(8), None)))
        self.kind = kind
        with self.canvas.before:
            if kind in ("grad", "blue"):
                Color(1, 1, 1, 1)
                self._r = RoundedRectangle(radius=[dp(14)], texture=get_grad(kind))
            elif kind == "danger":
                Color(.85, .25, .25, 1)
                self._r = RoundedRectangle(radius=[dp(14)])
            elif kind == "soft":
                Color(*T["card2"])
                self._r = RoundedRectangle(radius=[dp(14)])
            elif kind == "out":
                Color(*T["accent"])
                self._r = Line(width=1.2)
            else:
                self._r = None
        self.bind(pos=self._u, size=self._u,
                  state=lambda *_: setattr(self, "opacity", .75 if self.state == "down" else 1))

    def _u(self, *_):
        if self._r is None:
            return
        if isinstance(self._r, Line):
            self._r.rounded_rectangle = (self.x, self.y, self.width, self.height, dp(14))
        else:
            self._r.pos, self._r.size = self.pos, self.size


class Chip(ToggleButtonBehavior, Label):
    def __init__(self, text="", group=None, selected=False, h=40, val=None, font=None, **kw):
        super().__init__(text=text, group=group, size_hint_y=None, height=dp(h), font_size=sp(13),
                         font_name=font or cur_font(), color=T["text"], halign="center", valign="middle", **kw)
        self.val = text if val is None else val
        self.bind(size=lambda *_: setattr(self, "text_size", (self.width - dp(8), None)))
        with self.canvas.before:
            self._c = Color(*T["card2"])
            self._r = RoundedRectangle(radius=[dp(12)])
        self.bind(pos=self._u, size=self._u, state=self._s)
        if selected:
            self.state = "down"

    def _u(self, *_):
        self._r.pos, self._r.size = self.pos, self.size

    def _s(self, *_):
        self._c.rgba = T["accent"] if self.state == "down" else T["card2"]
        self.color = (1, 1, 1, 1) if self.state == "down" else T["text"]


def chips(options, selected=(), group=None, cols=2, h=40, fonts=None):
    """options: list of str or (val,label). fonts: optional {val: font name}. Returns (GridLayout, [Chip])."""
    g = GridLayout(cols=cols, spacing=dp(8), size_hint_y=None)
    cs = []
    for o in options:
        v, lab = (o if isinstance(o, tuple) else (o, o))
        c = Chip(lab, group=group, selected=(v in selected), h=h, val=v, font=(fonts or {}).get(v))
        cs.append(c)
        g.add_widget(c)
    rows = (len(cs) + cols - 1) // cols
    g.height = rows * dp(h) + max(0, rows - 1) * dp(8)
    return g, cs


def picked(cs):
    return [c.val for c in cs if c.state == "down"]


class Field(TextInput):
    def __init__(self, hint="", text="", password=False, filt=None, **kw):
        super().__init__(hint_text=hint, text=text, password=password, multiline=False, size_hint_y=None,
                         height=dp(48), background_normal="", background_active="", background_color=(0, 0, 0, 0),
                         foreground_color=T["text"], hint_text_color=T["sub"], cursor_color=T["green"],
                         padding=[dp(14), dp(14), dp(14), dp(14)], font_size=sp(14), font_name=cur_font(),
                         write_tab=False, **kw)
        if filt in ("int", "float"):
            self.input_filter = filt
        with self.canvas.before:
            Color(*T["field"])
            self._r = RoundedRectangle(radius=[dp(12)])
            Color(*T["border"])
            self._l = Line(width=1)
        self.bind(pos=self._u, size=self._u)

    def _u(self, *_):
        self._r.pos, self._r.size = self.pos, self.size
        self._l.rounded_rectangle = (self.x, self.y, self.width, self.height, dp(12))

    @property
    def val(self):
        return self.text.strip()


def pw_field(hint="Password"):
    f = Field(hint, password=True)
    b = GButton("Show", "ghost", h=44, size_hint_x=None, width=dp(60))

    def tog(*_):
        f.password = not f.password
        b.text = "Show" if f.password else "Hide"
    b.bind(on_release=tog)
    return hrow(48, f, b, spacing=2), f


class Ring(Widget):
    v = NumericProperty(0)

    def __init__(self, **kw):
        super().__init__(size_hint=(None, None), size=(dp(96), dp(96)), **kw)
        self.bind(pos=self.draw, size=self.draw, v=self.draw)
        self.lab = Label(font_size=sp(20), bold=True, color=T["text"], font_name=cur_font())
        self.add_widget(self.lab)

    def draw(self, *_):
        self.canvas.before.clear()
        cx, cy, r = self.center_x, self.center_y, self.width / 2 - dp(6)
        with self.canvas.before:
            Color(*T["card2"])
            Line(circle=(cx, cy, r), width=dp(6))
            Color(*T["green"])
            if self.v > 0:
                Line(circle=(cx, cy, r, 0, 360 * min(self.v, 1)), width=dp(6), cap="round")
        self.lab.center = self.center
        self.lab.text = "%d%%" % int(self.v * 100)


class Bars(Widget):
    def __init__(self, vals, **kw):
        super().__init__(size_hint_y=None, height=dp(120), **kw)
        self.vals = vals
        self.bind(pos=self.draw, size=self.draw)

    def draw(self, *_):
        self.canvas.clear()
        n = len(self.vals)
        if not n:
            return
        w = self.width / n
        with self.canvas:
            for i, v in enumerate(self.vals):
                Color(*T["card2"])
                RoundedRectangle(pos=(self.x + i * w + w * .2, self.y), size=(w * .6, self.height), radius=[dp(5)])
                Color(*T["green"])
                hh = max(dp(3), self.height * min(max(v, 0), 1))
                RoundedRectangle(pos=(self.x + i * w + w * .2, self.y), size=(w * .6, hh), radius=[dp(5)])


class LineChart(Widget):
    def __init__(self, vals, **kw):
        super().__init__(size_hint_y=None, height=dp(150), **kw)
        self.vals = vals
        self.bind(pos=self.draw, size=self.draw)

    def draw(self, *_):
        self.canvas.clear()
        v = self.vals
        if len(v) < 2:
            return
        lo, hi = min(v), max(v)
        span = (hi - lo) or 1
        pts = []
        for i, x in enumerate(v):
            pts += [self.x + dp(8) + i * (self.width - dp(16)) / (len(v) - 1),
                    self.y + dp(8) + (x - lo) / span * (self.height - dp(16))]
        with self.canvas:
            Color(*T["accent"])
            Line(points=pts, width=dp(2))
            Color(*T["green"])
            for i in range(0, len(pts), 2):
                Line(circle=(pts[i], pts[i + 1], dp(3)), width=dp(2))


class Bar(Widget):
    v = NumericProperty(0)

    def __init__(self, **kw):
        super().__init__(size_hint_y=None, height=dp(6), **kw)
        self.bind(pos=self.draw, size=self.draw, v=self.draw)

    def draw(self, *_):
        self.canvas.clear()
        with self.canvas:
            Color(*T["card2"])
            RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(3)])
            Color(1, 1, 1, 1)
            RoundedRectangle(pos=self.pos, size=(self.width * self.v, self.height), radius=[dp(3)],
                             texture=get_grad("grad"))


def logo(h=120):
    p = asset("logo.png")
    if p:
        return Image(source=p, size_hint_y=None, height=dp(h), fit_mode="contain")
    return L("Study [color=#33dd88]Fit[/color]", 34, bold=True, center=True, markup=True)


def avatar(h=56):
    p = asset("avatar.png")
    return Image(source=p, size_hint=(None, None), size=(dp(h), dp(h))) if p else \
        L((APP.prof.get("name") or "U")[:1].upper(), 22, bold=True, center=True, size_hint_x=None, width=dp(h))


def header(col, title, back=True, right=None):
    items = []
    if back:
        b = GButton("<", "soft", h=40, size_hint_x=None, width=dp(44))
        b.bind(on_release=lambda *_: APP.back())
        items.append(b)
    items.append(L(title, 20, bold=True))
    if right:
        items.append(right)
    col.add_widget(arow(*items, min_h=44))      # long titles wrap instead of overlapping the next widget


def with_icon(btn, png, size=22):
    """Put a small logo (assets/<png>) at the left edge of a button; no-op when the file is missing."""
    p = asset(png)
    if not p:
        return btn
    img = Image(size_hint=(None, None), size=(dp(size), dp(size)), source=p)
    btn.add_widget(img)

    def place(*_):
        img.pos = (btn.x + dp(16), btn.center_y - img.height / 2)
    btn.bind(pos=place, size=place)
    place()
    return btn


def seg(options, current, on_change):
    """Segment tabs (Today / Weekly / Exams ...)."""
    r = BoxLayout(size_hint_y=None, height=dp(38), spacing=dp(6))
    for o in options:
        c = Chip(t(o), group="seg_" + str(id(r)), selected=(o == current), h=38, val=o)
        c.allow_no_selection = False
        c.bind(on_release=lambda w, o=o: on_change(o))
        r.add_widget(c)
    return r


# ---------------- local database ----------------
class DB:
    def __init__(self, path):
        self.c = sqlite3.connect(path, check_same_thread=False)
        self.c.row_factory = sqlite3.Row
        self.lk = threading.RLock()
        self.c.executescript("""
        CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);
        CREATE TABLE IF NOT EXISTS weights(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, kg REAL);
        CREATE TABLE IF NOT EXISTS routine(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, start INT, end INT,
            title TEXT, category TEXT, subject TEXT, note TEXT, done INT DEFAULT 0, src TEXT DEFAULT 'ai');
        CREATE TABLE IF NOT EXISTS water(date TEXT PRIMARY KEY, ml INT);
        CREATE TABLE IF NOT EXISTS exams(id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT, date TEXT);
        CREATE TABLE IF NOT EXISTS homework(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, subject TEXT, done INT DEFAULT 0);
        CREATE TABLE IF NOT EXISTS wlog(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, name TEXT, minutes INT);
        CREATE TABLE IF NOT EXISTS notif(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INT, cat TEXT, title TEXT, body TEXT, nkey TEXT UNIQUE);
        CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, ref TEXT, amount INT, pay_id TEXT UNIQUE, ts INT);
        CREATE TABLE IF NOT EXISTS saved(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, data TEXT);
        """)
        self.c.commit()

    SYNC = ["weights", "routine", "water", "exams", "homework", "wlog", "purchases", "saved"]

    def ex(self, sql, a=()):
        with self.lk:
            cur = self.c.execute(sql, a)
            self.c.commit()
            return cur

    def all(self, sql, a=()):
        with self.lk:
            return [dict(r) for r in self.c.execute(sql, a).fetchall()]

    def one(self, sql, a=()):
        r = self.all(sql, a)
        return r[0] if r else None

    def get(self, k, d=None):
        r = self.one("SELECT v FROM kv WHERE k=?", (k,))
        return json.loads(r["v"]) if r else d

    def put(self, k, v):
        self.ex("INSERT OR REPLACE INTO kv(k,v) VALUES(?,?)", (k, json.dumps(v)))

    def touch(self):
        self.put("mod", int(time.time()))

    def export(self):
        d = {t_: self.all("SELECT * FROM " + t_) for t_ in self.SYNC}
        for k in ("profile", "settings", "meals", "workout", "draft"):
            d["kv_" + k] = self.get(k)
        return d

    def import_(self, d):
        with self.lk:
            for t_ in self.SYNC:
                self.c.execute("DELETE FROM " + t_)
                for r in d.get(t_, []):
                    cols = list(r.keys())
                    self.c.execute("INSERT INTO %s(%s) VALUES(%s)" % (t_, ",".join(cols), ",".join("?" * len(cols))),
                                   [r[c] for c in cols])
            self.c.commit()
        for k in ("profile", "settings", "meals", "workout", "draft"):
            if d.get("kv_" + k) is not None:
                self.put(k, d["kv_" + k])

    def wipe(self):
        with self.lk:
            for t_ in self.SYNC + ["notif"]:
                self.c.execute("DELETE FROM " + t_)
            self.c.execute("DELETE FROM kv")
            self.c.commit()


# ---------------- Firebase REST ----------------
FB = "https://identitytoolkit.googleapis.com/v1/accounts:%s?key=" + FIREBASE_API_KEY


def fb_sign_up(email, pw):
    return http_json("POST", FB % "signUp", {"email": email, "password": pw, "returnSecureToken": True})


def fb_sign_in(email, pw):
    return http_json("POST", FB % "signInWithPassword", {"email": email, "password": pw, "returnSecureToken": True})


def fb_sign_in_custom(tok):
    return http_json("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=" +
                     FIREBASE_API_KEY, {"token": tok, "returnSecureToken": True})


def fb_sign_in_idp(provider, id_token):
    """provider: 'google.com' or 'facebook.com'; id_token comes from the NATIVE login sdk."""
    return http_json("POST", FB % "signInWithIdp", {
        "postBody": "id_token=%s&providerId=%s" % (id_token, provider) if provider == "google.com"
        else "access_token=%s&providerId=%s" % (id_token, provider),
        "requestUri": "http://localhost", "returnSecureToken": True, "returnIdpCredential": True})


def fb_oob(kind, **kw):
    return http_json("POST", FB % "sendOobCode", dict(requestType=kind, **kw))


def fb_lookup(tok):
    return http_json("POST", FB % "lookup", {"idToken": tok})["users"][0]


def fb_update(tok, **kw):
    return http_json("POST", FB % "update", dict(idToken=tok, returnSecureToken=False, **kw))


def fb_delete(tok):
    return http_json("POST", FB % "delete", {"idToken": tok})


def fb_refresh(rt):
    return http_json("POST", "https://securetoken.googleapis.com/v1/token?key=" + FIREBASE_API_KEY,
                     {"grant_type": "refresh_token", "refresh_token": rt})


# >>> FIRESTORE RULES (paste in Firebase console > Firestore > Rules):
#   rules_version = '2';
#   service cloud.firestore { match /databases/{db}/documents {
#     match /users/{uid} { allow read, write: if request.auth != null && request.auth.uid == uid; } } }
def fs_url(uid):
    return "https://firestore.googleapis.com/v1/projects/%s/databases/(default)/documents/users/%s" % (
        FIREBASE_PROJECT_ID, uid)


def fs_get(uid, tok):
    try:
        j = http_json("GET", fs_url(uid), headers={"Authorization": "Bearer " + tok})
    except ApiError as e:
        if e.code == 404:
            return None
        raise
    f = j.get("fields", {})
    return {"ts": int(f["updatedAt"]["integerValue"]), "data": json.loads(f["data"]["stringValue"])}


def fs_put(uid, tok, data, ts):
    http_json("PATCH", fs_url(uid) + "?updateMask.fieldPaths=data&updateMask.fieldPaths=updatedAt",
              {"fields": {"data": {"stringValue": json.dumps(data)}, "updatedAt": {"integerValue": str(ts)}}},
              {"Authorization": "Bearer " + tok})


def fs_del(uid, tok):
    try:
        http_json("DELETE", fs_url(uid), headers={"Authorization": "Bearer " + tok})
    except ApiError:
        pass


ERR = {"EMAIL_EXISTS": "This email is already registered. Please login.",
       "INVALID_LOGIN_CREDENTIALS": "Wrong email or password.", "INVALID_PASSWORD": "Wrong password.",
       "EMAIL_NOT_FOUND": "No account found. Please create one.", "WEAK_PASSWORD": "Password is too weak.",
       "NO_INTERNET": "No internet connection.", "TOO_MANY_ATTEMPTS_TRY_LATER": "Too many attempts. Try later.",
       "USER_DISABLED": "This account is disabled.",
       "CREDENTIAL_TOO_OLD": "For safety please log out, log in again and then retry.",
       "TOKEN_EXPIRED": "Session expired. Please log in again.",
       # AI_NOT_CONFIGURED: developer note - set BACKEND_URL (or DEV_DIRECT_GEMINI + GEMINI_API_KEY for testing)
       "AI_NOT_CONFIGURED": "AI is not available right now. Please try again later.",
       "AI_EMPTY": "AI returned nothing. Try again.", "AI_BAD_JSON": "AI answer was invalid. Try again.",
       "NOT_CONFIGURED": "This feature is not available yet.",
       "Gemini key not configured": "AI is not available right now. Please try again later.",
       "Too many requests": "Too many AI requests. Please wait a few minutes."}


# =====================================================================
#  SCREENS
# =====================================================================
class Base(Screen):
    nav_tab = None
    scroll = True

    def on_pre_enter(self, *a):
        self.refresh()

    def refresh(self):
        self.clear_widgets()
        root = BoxLayout(orientation="vertical")
        col = vbox(12, fixed=not self.scroll)
        col.padding = [dp(18), dp(16), dp(18), dp(24)]
        self.col = col
        self.build_ui(col)
        if self.scroll:
            sv = ScrollView(do_scroll_x=False, bar_width=dp(2))
            sv.add_widget(col)
            root.add_widget(sv)
        else:
            root.add_widget(col)
        if self.nav_tab:
            root.add_widget(nav_bar(self.nav_tab))
        self.add_widget(root)

    def build_ui(self, col):
        pass


def nav_bar(active):
    bar = BoxLayout(size_hint_y=None, height=dp(58))
    with bar.canvas.before:
        Color(*T["card"])
        r = Rectangle()
    bar.bind(pos=lambda *_: setattr(r, "pos", bar.pos), size=lambda *_: setattr(r, "size", bar.size))
    for key, scr in (("Home", "home"), ("Study", "study"), ("Fitness", "workout"), ("Diet", "diet"),
                     ("Profile", "settings")):
        b = GButton(t(key), "ghost", h=58, font_size=sp(12))
        b.size_hint_y = 1
        b.color = T["green"] if key == active else T["sub"]
        b.bind(on_release=lambda *_, s=scr: APP.go(s, root=True))
        bar.add_widget(b)
    return bar


# ---------- 1. Splash ----------
class SplashS(Base):
    scroll = False

    def build_ui(self, col):
        col.add_widget(Widget())
        col.add_widget(logo(150))
        col.add_widget(L("Study  •  Fitness  •  Diet", 14, "sub", center=True))
        col.add_widget(gap(20))
        col.add_widget(L("Your Smart Companion\nfor a Healthier & Brighter Future", 14, "sub", center=True))
        col.add_widget(Widget())
        bar = Bar()
        col.add_widget(bar)
        col.add_widget(L("Loading...   v" + APP_VERSION, 12, "sub", center=True))
        from kivy.animation import Animation
        Animation(v=1, d=2.2).start(bar)
        Clock.schedule_once(lambda *_: APP.after_splash(), 2.4)


# ---------- 2. Language ----------
class LangS(Base):
    def build_ui(self, col):
        col.add_widget(logo(90))
        col.add_widget(L(t("Select Language"), 22, bold=True, center=True))
        col.add_widget(L("Choose your preferred language", 13, "sub", center=True))
        opts, fnts = lang_options()
        g, cs = chips(opts, [APP.prof.get("lang", "en")], "lang", 2, 46, fonts=fnts)
        col.add_widget(g)
        self.cs = cs
        b = GButton(t("Continue"))
        b.bind(on_release=lambda *_: self.go(False))
        col.add_widget(b)
        s = GButton(t("Skip for Now") + " (English)", "ghost")
        s.bind(on_release=lambda *_: self.go(True))
        col.add_widget(s)
        if not any(c.state == "down" for c in cs):
            cs[0].state = "down"

    def go(self, skip):
        sel = picked(self.cs)
        APP.prof["lang"] = "en" if skip or not sel else sel[0]
        APP.db.put("lang_chosen", True)
        APP.save_prof()
        if APP.sess.get("uid"):
            APP.go("settings", root=True)
        else:
            APP.go("welcome", root=True)


# ---------- 3. Welcome / Login ----------
class WelcomeS(Base):
    def build_ui(self, col):
        col.add_widget(logo(100))
        col.add_widget(L(t("Welcome Back!"), 24, bold=True, center=True))
        col.add_widget(L("Your goals, your routine, our AI.\nLet's get you started.", 13, "sub", center=True))
        for name, key, png in (("Continue with Google", "google", "google.png"),
                               ("Continue with Facebook", "facebook", "facebook.png")):
            b = GButton(t(name), "soft" if key == "google" else "blue", h=48)
            b.bind(on_release=lambda *_, k=key: APP.social_login(k))
            col.add_widget(with_icon(b, png))
        col.add_widget(L("—  OR  —", 12, "sub", center=True))
        self.ident = Field("Email or Mobile Number (+91...)")
        col.add_widget(self.ident)
        row, self.pw = pw_field(t("Password"))
        col.add_widget(row)
        fp = GButton(t("Forgot Password?"), "ghost", h=32)
        fp.bind(on_release=lambda *_: self.forgot())
        col.add_widget(fp)
        lg = GButton(t("Login"))
        lg.bind(on_release=lambda *_: self.login())
        col.add_widget(lg)
        ca = GButton(t("Create Account"), "out")
        ca.bind(on_release=lambda *_: APP.go("signup"))
        col.add_widget(ca)

    def login(self):
        ident, pw = self.ident.val, self.pw.text
        if not ident:
            return APP.toast("Enter email or mobile number")
        digits = re.sub(r"[\s\-]", "", ident)
        if re.match(r"^\+?\d{10,13}$", digits):
            phone = digits if digits.startswith("+") else "+91" + digits[-10:]
            return APP.otp_start(phone, mode="login")
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", ident):
            return APP.toast("Enter a valid email")
        if not pw:
            return APP.toast("Enter your password")
        APP.bg(lambda: fb_sign_in(ident, pw), lambda r: APP.on_login(r, ident))

    def forgot(self):
        e = self.ident.val
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", e):
            return APP.toast("Type your email above first")
        APP.bg(lambda: fb_oob("PASSWORD_RESET", email=e), lambda r: APP.toast("Password reset link sent to " + e))


# ---------- 4. Sign up ----------
class SignupS(Base):
    def build_ui(self, col):
        header(col, t("Create Account"))
        col.add_widget(L("Join Study Fit and build your better tomorrow.", 13, "sub"))
        self.name = Field("Full Name")
        self.ident = Field("Email Address or Mobile Number")
        r1, self.pw = pw_field("Create a strong password (min 8)")
        r2, self.pw2 = pw_field("Confirm password")
        for w in (self.name, self.ident, r1, r2):
            col.add_widget(w)
        self.terms = Chip("I accept Terms of Service & Privacy Policy", h=56)
        col.add_widget(self.terms)
        row = hrow(34, GButton("Read Terms", "ghost", h=34), GButton("Read Privacy", "ghost", h=34))
        row.children[1].bind(on_release=lambda *_: open_url(TERMS_URL))
        row.children[0].bind(on_release=lambda *_: open_url(PRIVACY_URL))
        col.add_widget(row)
        b = GButton("Create Account")
        b.bind(on_release=lambda *_: self.submit())
        col.add_widget(b)

    def submit(self):
        n, i, p1, p2 = self.name.val, self.ident.val, self.pw.text, self.pw2.text
        if not (n and i and p1 and p2):
            return APP.toast("Please fill all fields")
        if self.terms.state != "down":
            return APP.toast("Please accept Terms and Privacy Policy")
        if len(p1) < 8:
            return APP.toast("Password must be at least 8 characters")
        if p1 != p2:
            return APP.toast("Passwords do not match")
        APP.prof["name"] = n
        digits = re.sub(r"[\s\-]", "", i)
        if re.match(r"^\+?\d{10,13}$", digits):
            phone = digits if digits.startswith("+") else "+91" + digits[-10:]
            return APP.otp_start(phone, mode="login")
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", i):
            return APP.toast("Enter a valid email or mobile number")

        def work():
            r = fb_sign_up(i, p1)
            try:
                fb_update(r["idToken"], displayName=n)
                fb_oob("VERIFY_EMAIL", idToken=r["idToken"])
            except ApiError:
                pass
            return r
        APP.bg(work, lambda r: APP.on_login(r, i, new=True))


# ---------- 5. OTP ----------
class OtpS(Base):
    def build_ui(self, col):
        header(col, "Verify Your Mobile Number")
        col.add_widget(L("We sent a 6-digit OTP to\n" + APP.otp.get("phone", ""), 14, "sub", center=True))
        self.hidden = TextInput(size_hint=(None, None), size=(dp(1), dp(1)), opacity=0, input_filter="int",
                                multiline=False)
        self.hidden.bind(text=self.upd)
        col.add_widget(self.hidden)
        box = BoxLayout(size_hint_y=None, height=dp(54), spacing=dp(8))
        self.boxes = []
        for _ in range(6):
            b = GButton("", "soft", h=54, font_size=sp(22))
            b.bind(on_release=lambda *_: setattr(self.hidden, "focus", True))
            self.boxes.append(b)
            box.add_widget(b)
        col.add_widget(box)
        self.timer = L("", 13, "sub", center=True)
        col.add_widget(self.timer)
        v = GButton("Verify")
        v.bind(on_release=lambda *_: self.verify())
        col.add_widget(v)
        self.resend = GButton("Resend OTP", "ghost")
        self.resend.bind(on_release=lambda *_: self.do_resend())
        col.add_widget(self.resend)
        c = GButton("Change Mobile Number", "ghost")
        c.bind(on_release=lambda *_: APP.back())
        col.add_widget(c)
        self.left = max(0, int(APP.otp.get("until", 0) - time.time()))
        if hasattr(self, "ev"):
            self.ev.cancel()
        self.ev = Clock.schedule_interval(self.tick, 1)
        Clock.schedule_once(lambda *_: setattr(self.hidden, "focus", True), .4)

    def on_leave(self, *a):
        if hasattr(self, "ev"):
            self.ev.cancel()

    def tick(self, *_):
        self.left = max(0, int(APP.otp.get("until", 0) - time.time()))
        self.timer.text = "Resend OTP in 00:%02d" % self.left if self.left else "You can resend the OTP now"
        self.resend.disabled = self.left > 0

    def upd(self, inst, val):
        val = val[:6]
        if val != inst.text:
            inst.text = val
        for i, b in enumerate(self.boxes):
            b.text = val[i] if i < len(val) else ""

    def do_resend(self):
        APP.otp_send(APP.otp["phone"], APP.otp["mode"], silent=False)

    def verify(self):
        code = self.hidden.text
        if len(code) != 6:
            return APP.toast("Enter the 6-digit OTP")
        APP.otp_verify(code)


# ---------- 6. Account backup ----------
class BackupS(Base):
    def build_ui(self, col):
        col.add_widget(logo(70))
        col.add_widget(L("Secure Your Account", 22, bold=True, center=True))
        col.add_widget(L("Add a backup method so you can recover your account and data if you switch devices.",
                         13, "sub", center=True))
        for title, sub, fn in (
                ("Mobile Number", "Verify with OTP", lambda: APP.otp_link()),
                ("Email Address", "Verify with email link", lambda: APP.send_verify_mail()),
                ("Skip for Now", "You can add later in settings", lambda: None)):
            c = TapCard()
            c.add_widget(L(title, 15, bold=True))
            c.add_widget(L(sub, 12, "sub"))
            c.bind(on_release=lambda *_, f=fn: f())
            col.add_widget(c)
        col.add_widget(L("Last synced: " + APP.last_sync_txt(), 12, "sub", center=True))
        b = GButton(t("Continue"))
        b.bind(on_release=lambda *_: APP.go("p_personal"))
        col.add_widget(b)


# ---------- 7a. Personal ----------
class PersonalS(Base):
    def build_ui(self, col):
        p = APP.prof
        header(col, "Profile Setup - Personal Details")
        col.add_widget(L("Step 1 of 4", 12, "green"))
        self.name = Field("Full Name", p.get("name", ""))
        self.dob = Field("Date of Birth (DD-MM-YYYY) or Age", p.get("dob_in", ""))
        self.wake = Field("Daily wake-up time e.g. 6:00 AM", p.get("wake_in", "6:00 AM"))
        self.sleep = Field("Preferred sleep time e.g. 10:30 PM", p.get("sleep_in", "10:30 PM"))
        for w in (L("Full Name", 12, "sub"), self.name, L("Date of Birth or Age", 12, "sub"), self.dob,
                  L("Wake-up time", 12, "sub"), self.wake, L("Sleep time", 12, "sub"), self.sleep):
            col.add_widget(w)
        col.add_widget(L("Preferred Language", 12, "sub"))
        opts, fnts = lang_options()
        g, self.lg = chips(opts, [p.get("lang", "en")], "plang", 2, 40, fonts=fnts)
        col.add_widget(g)
        self.minor = Chip("I am under 18 and my parent/guardian allows me to use this app", h=66)
        if p.get("minor_ok"):
            self.minor.state = "down"
        col.add_widget(self.minor)
        col.add_widget(L("We only collect what is needed for your plan. Age is used for safety limits.", 11, "sub"))
        b = GButton(t("Next"))
        b.bind(on_release=lambda *_: self.nxt())
        col.add_widget(b)

    def nxt(self):
        age, dob = parse_age(self.dob.val)
        w, s = parse_time(self.wake.val), parse_time(self.sleep.val)
        if not self.name.val:
            return APP.toast("Enter your name")
        if age is None:
            return APP.toast("Enter valid date of birth (DD-MM-YYYY) or age")
        if w is None or s is None:
            return APP.toast("Enter valid wake/sleep time, e.g. 6:00 AM")
        if age < 18 and self.minor.state != "down":
            return APP.toast("Parent/guardian permission is required under 18")
        sel = picked(self.lg)
        APP.prof.update(name=self.name.val, age=age, dob=dob, dob_in=self.dob.val, wake=hhmm(w), sleep=hhmm(s),
                        wake_in=self.wake.val, sleep_in=self.sleep.val, minor_ok=self.minor.state == "down",
                        lang=sel[0] if sel else APP.prof.get("lang", "en"))
        APP.save_prof()
        APP.go("p_weight")


# ---------- 7b. Weight ----------
class WeightSetupS(Base):
    def build_ui(self, col):
        p = APP.prof
        header(col, "Weight & Body Profile")
        col.add_widget(L("Step 2 of 4  -  Optional", 12, "green"))
        col.add_widget(L("What is your current weight?", 16, bold=True))
        self.w = Field("Enter weight", filt="float")
        col.add_widget(self.w)
        g, self.unit = chips(["kg", "lb"], [p.get("unit", "kg")], "unit", 2, 38)
        col.add_widget(g)
        self.h = Field("Height in cm (optional)", str(p.get("height", "") or ""), filt="float")
        col.add_widget(self.h)
        col.add_widget(L("Fitness experience", 12, "sub"))
        g2, self.exp = chips(["Beginner", "Intermediate", "Advanced"], [p.get("exp", "Beginner")], "exp", 3, 38)
        col.add_widget(g2)
        col.add_widget(L("Preferred activity level", 12, "sub"))
        g3, self.act = chips(["Light", "Moderate", "Active"], [p.get("activity", "Moderate")], "act", 3, 38)
        col.add_widget(g3)
        col.add_widget(L("Weight is optional and never used alone to decide diet or workout intensity.", 11, "sub"))
        b = GButton("Save Weight & Continue")
        b.bind(on_release=lambda *_: self.save(True))
        col.add_widget(b)
        s = GButton(t("Skip for Now"), "ghost")
        s.bind(on_release=lambda *_: self.save(False))
        col.add_widget(s)

    def save(self, with_w):
        u = (picked(self.unit) or ["kg"])[0]
        APP.prof.update(unit=u, exp=(picked(self.exp) or ["Beginner"])[0],
                        activity=(picked(self.act) or ["Moderate"])[0])
        try:
            APP.prof["height"] = float(self.h.val) if self.h.val else None
        except ValueError:
            return APP.toast("Invalid height")
        if with_w and self.w.val:
            if not APP.add_weight(self.w.val, u):
                return
        APP.save_prof()
        APP.go("p_goals")


# ---------- 7c. Goals ----------
class GoalsS(Base):
    def build_ui(self, col):
        header(col, "Choose Your Goals")
        col.add_widget(L("Step 3 of 4  -  you can choose multiple", 12, "green"))
        sel = APP.prof.get("goals", [])
        opts = [("study", "Study Planning"), ("fitness", "Fitness & Daily Activity"),
                ("diet", "Food & Meal Planning"), ("routine", "Complete Daily Routine")]
        g, self.cs = chips(opts, sel, None, 1, 54)
        col.add_widget(g)
        b = GButton(t("Next"))
        b.bind(on_release=lambda *_: self.nxt())
        col.add_widget(b)

    def nxt(self):
        sel = picked(self.cs)
        if not sel:
            return APP.toast("Select at least one goal")
        if "routine" in sel:
            sel = ["study", "fitness", "diet", "routine"]
        APP.prof["goals"] = sel
        APP.save_prof()
        APP.go("p_life")


# ---------- 7d. Lifestyle ----------
class LifeS(Base):
    def build_ui(self, col):
        p = APP.prof
        g = p.get("goals", [])
        header(col, "Lifestyle & Preferences")
        col.add_widget(L("Step 4 of 4", 12, "green"))
        if "diet" in g:
            col.add_widget(L("Diet preference", 12, "sub"))
            gr, self.food = chips(["Vegetarian", "Non-Vegetarian", "Vegan", "No Specific Preference"],
                                  [p.get("food_pref", "No Specific Preference")], "food", 2, 38)
            col.add_widget(gr)
            self.allergy = Field("Food allergies (if any) e.g. nuts, dairy", p.get("allergies", ""))
            col.add_widget(self.allergy)
        else:
            self.food, self.allergy = [], Field("")
        if "fitness" in g:
            col.add_widget(L("Workout preference", 12, "sub"))
            gr, self.wp = chips(["Home Workout", "Gym Workout", "Walking", "Stretching", "General Activity"],
                                p.get("wprefs", ["Home Workout"]), None, 2, 38)
            col.add_widget(gr)
            col.add_widget(L("Preferred workout time", 12, "sub"))
            gr, self.wt = chips(["Morning", "Afternoon", "Evening"], [p.get("workout_time", "Evening")],
                                "wt", 3, 38)
            col.add_widget(gr)
            self.wm = Field("Minutes available for workout (e.g. 30)", str(p.get("workout_minutes", 30)), filt="int")
            col.add_widget(self.wm)
            self.injury = Field("Injuries / health limits (optional)", p.get("injuries", ""))
            col.add_widget(self.injury)
        else:
            self.wp, self.wt, self.wm, self.injury = [], [], Field(""), Field("")
        if "study" in g or "routine" in g:
            col.add_widget(L("Study details", 12, "sub"))
            gr, self.cls = chips([("10", "Class 10th"), ("12", "Class 12th")], [p.get("cls", "10")], "cls", 2, 38)
            col.add_widget(gr)
            self.ss = Field("School/college start e.g. 7:30 AM", p.get("school_start_in", ""))
            self.se = Field("School/college end e.g. 2:00 PM", p.get("school_end_in", ""))
            self.sf = Field("Free to study from e.g. 4:00 PM", p.get("study_from_in", ""))
            self.sh = Field("Study hours per day (e.g. 3)", str(p.get("study_hours", 3)), filt="float")
            for w in (self.ss, self.se, self.sf, self.sh):
                col.add_widget(w)
            col.add_widget(L("School days", 12, "sub"))
            gr, self.days = chips([(0, "Mon"), (1, "Tue"), (2, "Wed"), (3, "Thu"), (4, "Fri"), (5, "Sat")],
                                  p.get("school_days", [0, 1, 2, 3, 4, 5]), None, 6, 36)
            col.add_widget(gr)
            col.add_widget(L("Subjects", 12, "sub"))
            gr, self.subj = chips(SUBJECTS["10"] + [s for s in SUBJECTS["12"] if s not in SUBJECTS["10"]],
                                  p.get("subjects", []), None, 2, 46)
            col.add_widget(gr)
        else:
            self.cls = self.subj = self.days = []
            self.ss = self.se = self.sf = self.sh = Field("")
        b = GButton(t("Next"))
        b.bind(on_release=lambda *_: self.nxt())
        col.add_widget(b)

    def nxt(self):
        p = APP.prof
        g = p.get("goals", [])
        if "diet" in g:
            p["food_pref"] = (picked(self.food) or ["No Specific Preference"])[0]
            p["allergies"] = self.allergy.val
        if "fitness" in g:
            p["wprefs"] = picked(self.wp) or ["Home Workout"]
            p["workout_time"] = (picked(self.wt) or ["Evening"])[0]
            try:
                p["workout_minutes"] = max(10, min(120, int(self.wm.val or 30)))
            except ValueError:
                return APP.toast("Invalid workout minutes")
            p["injuries"] = self.injury.val
        if "study" in g or "routine" in g:
            vals = {}
            for k, f in (("school_start", self.ss), ("school_end", self.se), ("study_from", self.sf)):
                if f.val:
                    m = parse_time(f.val)
                    if m is None:
                        return APP.toast("Invalid time: " + f.val)
                    vals[k], vals[k + "_in"] = hhmm(m), f.val
                else:
                    vals[k], vals[k + "_in"] = None, ""
            if bool(vals["school_start"]) != bool(vals["school_end"]) or \
                    (vals["school_start"] and parse_time(vals["school_end"]) <= parse_time(vals["school_start"])):
                return APP.toast("School end must be after start")
            try:
                p["study_hours"] = max(0.5, min(10, float(self.sh.val or 3)))
            except ValueError:
                return APP.toast("Invalid study hours")
            p.update(vals)
            p["cls"] = (picked(self.cls) or ["10"])[0]
            p["school_days"] = picked(self.days)
            p["subjects"] = picked(self.subj)
        APP.save_prof()
        APP.go("p_review")


# ---------- 7e. Review ----------
class ReviewS(Base):
    def build_ui(self, col):
        p = APP.prof
        header(col, "Review Your Profile")
        c = Card()
        c.add_widget(L("Personal Details", 15, bold=True, col="green"))
        for k, v in (("Name", p.get("name")), ("Age", p.get("age")), ("Language", lang_name(p.get("lang", "en"))),
                     ("Wake-up", p.get("wake_in")), ("Sleep", p.get("sleep_in")),
                     ("Diet", p.get("food_pref")), ("Allergies", p.get("allergies") or "-"),
                     ("Workout", ", ".join(p.get("wprefs", [])) or "-"),
                     ("School", (p.get("school_start_in") or "-") + " to " + (p.get("school_end_in") or "-")),
                     ("Goals", ", ".join(p.get("goals", [])))):
            c.add_widget(arow(L(k, 12, "sub", size_hint_x=.35), L(str(v or "-"), 13), min_h=22))
        col.add_widget(c)
        b = GButton("Finish Setup")
        b.bind(on_release=lambda *_: self.finish(False))
        col.add_widget(b)
        g = GButton("Generate My Personalized Plan", "blue")
        g.bind(on_release=lambda *_: self.finish(True))
        col.add_widget(g)

    def finish(self, gen):
        APP.prof["setup_done"] = True
        APP.save_prof()
        APP.sync_bg()
        APP.go("home", root=True)
        if gen:
            Clock.schedule_once(lambda *_: APP.gen_routine(), .5)


# ---------- 8. Home ----------
class HomeS(Base):
    nav_tab = "Home"

    def build_ui(self, col):
        p = APP.prof
        hr = dt.datetime.now().hour
        greet = "Good Morning" if hr < 12 else "Good Afternoon" if hr < 17 else "Good Evening"
        bell = GButton("Alerts", "soft", h=38, size_hint_x=None, width=dp(64))
        bell.bind(on_release=lambda *_: APP.go("notif"))
        pr = GButton("Me", "soft", h=38, size_hint_x=None, width=dp(44))
        pr.bind(on_release=lambda *_: APP.go("settings", root=True))
        v = vbox(2)
        v.add_widget(L(t(greet) + ", " + (p.get("name") or "").split(" ")[0] + "!", 20, bold=True))
        v.add_widget(L(dt.date.today().strftime("%A, %d %B %Y"), 12, "sub"))
        row = BoxLayout(size_hint_y=None, height=dp(56), spacing=dp(6))
        row.add_widget(v)
        row.add_widget(bell)
        row.add_widget(pr)
        col.add_widget(row)
        items = APP.routine_for(dt.date.today())
        tasks = [i for i in items if i["category"] not in ("school", "sleep")]
        done = sum(1 for i in tasks if i["done"])
        c = Card()
        r = Ring()
        r.v = done / len(tasks) if tasks else 0
        info = vbox(4)
        info.add_widget(L("Daily Progress", 15, bold=True))
        info.add_widget(L("%d/%d tasks completed" % (done, len(tasks)) if tasks else
                          "No plan yet - generate your routine", 13, "sub"))
        rw = BoxLayout(size_hint_y=None, height=dp(100), spacing=dp(12))
        rw.add_widget(r)
        rw.add_widget(info)
        c.add_widget(rw)
        col.add_widget(c)
        g = APP.prof.get("goals", [])
        cards = []
        if "study" in g:
            cards.append(("Study Planner", "Learn, improve, achieve", "study"))
        if "fitness" in g:
            cards.append(("Workout Plan", "Stay fit", "workout"))
        if "diet" in g:
            cards.append(("Diet Planner", "Eat better, feel healthier", "diet"))
        cards.append(("Daily Routine", "Balance your life", "routine"))
        grid = GridLayout(cols=2, spacing=dp(10), size_hint_y=None)
        for title, sub, scr in cards:
            tc = TapCard(pad=12, spacing=2)
            tc.add_widget(L(t(title), 14, bold=True))
            tc.add_widget(L(sub, 11, "sub"))
            tc.bind(on_release=lambda *_, s=scr: APP.go(s))
            grid.add_widget(tc)
        grid.bind(minimum_height=grid.setter("height"))
        col.add_widget(grid)
        sc = Card()
        va = GButton("View All", "ghost", h=26, size_hint_x=None, width=dp(70))
        va.bind(on_release=lambda *_: APP.go("routine"))
        sc.add_widget(arow(L("Today's Schedule", 15, bold=True), va, min_h=26))
        shown = [i for i in items if not i["done"]][:5] or items[:5]
        if not items:
            sc.add_widget(L("Nothing planned yet.", 13, "sub"))
        for i in shown:
            sc.add_widget(arow(L(fmt_min(i["start"]), 12, "sub", size_hint_x=.3), L(i["title"], 13), min_h=24))
        col.add_widget(sc)
        qa = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        for txt, fn in (("Regenerate Plan", lambda: APP.gen_routine()), ("+250ml Water", lambda: APP.add_water(250)),
                        ("Log Weight", lambda: APP.go("weight")), ("Store", lambda: APP.go("store"))):
            b = GButton(txt, "soft", h=44, font_size=sp(11))
            b.bind(on_release=lambda *_, f=fn: f())
            qa.add_widget(b)
        col.add_widget(qa)
        pg = GButton("View Progress", "out")
        pg.bind(on_release=lambda *_: APP.go("progress"))
        col.add_widget(pg)


# ---------- Routine ----------
class RoutineS(Base):
    tab = "Today"
    note_txt = ""

    def build_ui(self, col):
        header(col, t("Daily Routine"))
        col.add_widget(seg(["Today", "Tomorrow", "Weekly"], self.tab, self.set_tab))
        # ---- AI coach: the AI plans the routine; the student only talks to it ----
        c = Card(col="card2")
        c.add_widget(L("AI Routine Coach", 15, bold=True))
        info = APP.db.get("plan_info")
        if info and info.get("summary"):
            c.add_widget(L(info["summary"], 12, "green"))
        else:
            c.add_widget(L("Tell the AI anything - an event, a test, feeling tired, a new goal. "
                           "It rebuilds your routine around it.", 12, "sub"))
        self.note = Field("e.g. Cricket 5-6 PM today, maths test on Friday", self.note_txt)
        self.note.bind(text=lambda i, v: setattr(self, "note_txt", v))
        c.add_widget(self.note)
        r = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(8))
        wk = GButton(t("Generate My AI Routine") if not APP.routine_for(dt.date.today()) else "Plan My Week",
                     "grad", h=46, font_size=sp(13))
        wk.bind(on_release=lambda *_: self.plan(False))
        td = GButton("Re-plan Today", "blue", h=46, font_size=sp(13))
        td.bind(on_release=lambda *_: self.plan(True))
        r.add_widget(wk)
        r.add_widget(td)
        c.add_widget(r)
        up = APP.db.get("undo_plan")
        if up and (up.get("old") or up.get("new")):
            ub = GButton("Undo last AI plan", "ghost", h=34, font_size=sp(12))
            ub.bind(on_release=lambda *_: APP.undo_plan(self))
            c.add_widget(ub)
        for w in (info or {}).get("warnings", [])[:3]:
            c.add_widget(L("• " + w, 11, "sub"))
        col.add_widget(c)
        days = {"Today": [0], "Tomorrow": [1], "Weekly": list(range(7))}[self.tab]
        for off in days:
            day = dt.date.today() + dt.timedelta(days=off)
            if self.tab == "Weekly":
                col.add_widget(L(day.strftime("%A, %d %b"), 14, bold=True, col="green"))
            its = APP.routine_for(day)
            if not its:
                col.add_widget(L("No plan for this day. Generate or add a task.", 12, "sub"))
            for it in its:
                col.add_widget(self.item_card(it, day, compact=self.tab == "Weekly"))
        r = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        for txt, fn in (("Add Task", self.add_task), ("Edit Preferences", lambda: APP.go("p_life"))):
            b = GButton(txt, "soft", h=44)
            b.bind(on_release=lambda *_, f=fn: f())
            r.add_widget(b)
        col.add_widget(r)

    def plan(self, today_only):
        APP.gen_routine(note=self.note_txt.strip(), today_only=today_only)   # note is cleared after success

    def set_tab(self, o):
        self.tab = o
        self.refresh()

    def item_card(self, it, day, compact=False):
        c = Card(pad=10, spacing=4)
        mark = "[done] " if it["done"] else ""
        c.add_widget(L("%s%s - %s" % (mark, fmt_min(it["start"]), it["title"]), 14, bold=True,
                       col="sub" if it["done"] else "text"))
        meta = it["category"].title() + ((" • " + it["subject"]) if it["subject"] else "") + \
            ("  (%d min)" % (it["end"] - it["start"]) if it["end"] > it["start"] else "")
        c.add_widget(L(meta, 11, "sub"))
        if not compact and it["note"]:
            c.add_widget(L(it["note"], 11, "sub"))
        if not compact and it["category"] not in ("school", "sleep"):
            r = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(6))
            acts = [("Start", lambda i=it: APP.run_timer(i["title"], max(1, i["end"] - i["start"]),
                                                          lambda: APP.mark(i["id"], 1, self))),
                    ("Undo" if it["done"] else "Done", lambda i=it: APP.mark(i["id"], 0 if i["done"] else 1, self)),
                    ("Move", lambda i=it: self.move(i)),
                    ("Del", lambda i=it: (APP.db.ex("DELETE FROM routine WHERE id=?", (i["id"],)),
                                          APP.db.touch(), self.refresh()))]
            for txt, fn in acts:
                b = GButton(txt, "soft", h=36, font_size=sp(12))
                b.bind(on_release=lambda *_, f=fn: f())
                r.add_widget(b)
            c.add_widget(r)
        return c

    def move(self, it):
        def ok(v):
            s = parse_time(v["start"])
            if s is None:
                APP.toast("Invalid time")
                return False
            e = s + (it["end"] - it["start"])
            clash = APP.clash(it["date"], s, e, it["id"])
            if clash:
                APP.toast("Clashes with: " + clash)
                return False
            APP.db.ex("UPDATE routine SET start=?, end=?, src='manual' WHERE id=?", (s, e, it["id"]))
            APP.db.touch()
            self.refresh()
        APP.ask("Reschedule: " + it["title"], [("start", "New start time e.g. 5:30 PM", fmt_min(it["start"]))], ok)

    def add_task(self):
        def ok(v):
            s, e = parse_time(v["start"]), parse_time(v["end"])
            if not v["title"] or s is None or e is None or e <= s:
                APP.toast("Enter title and valid start/end")
                return False
            day = (dt.date.today() + dt.timedelta(days=1 if self.tab == "Tomorrow" else 0)).isoformat()
            clash = APP.clash(day, s, e)
            if clash:
                APP.toast("Clashes with: " + clash)
                return False
            APP.db.ex("INSERT INTO routine(date,start,end,title,category,subject,note,src) VALUES(?,?,?,?,?,?,?,?)",
                      (day, s, e, v["title"][:60], v["cat"].lower() if v["cat"].lower() in CATS else "other",
                       "", "", "manual"))
            APP.db.touch()
            self.refresh()
        APP.ask("Add Task", [("title", "Task title", ""), ("start", "Start e.g. 6:00 PM", ""),
                             ("end", "End e.g. 7:00 PM", ""), ("cat", "Type: study/workout/meal/break/other", "study")], ok)


# ---------- Study ----------
class StudyS(Base):
    nav_tab = "Study"
    tab = "Today"

    def build_ui(self, col):
        p = APP.prof
        header(col, t("Study Planner"), back=False)
        col.add_widget(seg(["Today", "Weekly", "Exams"], self.tab, self.set_tab))
        cls = p.get("cls", "10")
        if self.tab == "Today":
            its = [i for i in APP.routine_for(dt.date.today()) if i["category"] in ("study", "revision", "homework")]
            c = Card()
            c.add_widget(L("Today's Schedule", 15, bold=True))
            if not its:
                c.add_widget(L("No study sessions planned. Generate your AI routine.", 12, "sub"))
            for i in its:
                c.add_widget(arow(L("%s  %s" % (fmt_min(i["start"]), i["title"]), 13, size_hint_x=.75),
                                  self.mk(i), min_h=30))
            col.add_widget(c)
            g = GButton("Generate AI Study Plan", "blue")
            g.bind(on_release=lambda *_: APP.gen_routine())
            col.add_widget(g)
            col.add_widget(L("My Subjects (Class %s)" % cls, 15, bold=True))
            for s in (p.get("subjects") or SUBJECTS.get(cls, [])):
                tc = TapCard(pad=10)
                tc.add_widget(L(s, 14))
                tc.add_widget(L("Notes • PYQs • Solutions" if NOTES_ENABLED else "Notes coming soon", 11, "sub"))
                tc.bind(on_release=lambda *_, s=s: (setattr(APP, "subject", s), APP.go("notes")))
                col.add_widget(tc)
            col.add_widget(L("Homework Tracker", 15, bold=True))
            for h in APP.db.all("SELECT * FROM homework ORDER BY done, id DESC"):
                r = arow(L(("[done] " if h["done"] else "") + h["title"], 13, size_hint_x=.6),
                         GButton("Toggle", "soft", h=32, size_hint_x=None, width=dp(64)),
                         GButton("X", "soft", h=32, size_hint_x=None, width=dp(36)), min_h=34)
                r.children[1].bind(on_release=lambda *_, h=h: (APP.db.ex("UPDATE homework SET done=? WHERE id=?",
                                                                          (0 if h["done"] else 1, h["id"])),
                                                               APP.db.touch(), self.refresh()))
                r.children[0].bind(on_release=lambda *_, h=h: (APP.db.ex("DELETE FROM homework WHERE id=?", (h["id"],)),
                                                               APP.db.touch(), self.refresh()))
                col.add_widget(r)
            a = GButton("Add Homework", "soft")
            a.bind(on_release=lambda *_: APP.ask("Add Homework", [("t", "Task", ""), ("s", "Subject", "")],
                                                 lambda v: (APP.db.ex("INSERT INTO homework(title,subject) VALUES(?,?)",
                                                                      (v["t"][:80], v["s"][:40])),
                                                            APP.db.touch(), self.refresh()) if v["t"] else False))
            col.add_widget(a)
        elif self.tab == "Weekly":
            vals, labs = [], GridLayout(cols=7, size_hint_y=None, height=dp(18))
            for off in range(-6, 1):
                d = dt.date.today() + dt.timedelta(days=off)
                its = [i for i in APP.routine_for(d) if i["category"] in ("study", "revision")]
                vals.append(sum(1 for i in its if i["done"]) / len(its) if its else 0)
                labs.add_widget(L(d.strftime("%a"), 10, "sub", center=True))
            col.add_widget(L("Study sessions completed (last 7 days)", 13, "sub"))
            col.add_widget(Bars(vals))
            col.add_widget(labs)
        else:
            col.add_widget(L("Exam Countdown", 15, bold=True))
            ex = APP.db.all("SELECT * FROM exams ORDER BY date")
            if not ex:
                col.add_widget(L("No exams added.", 12, "sub"))
            for e in ex:
                try:
                    left = (dt.date.fromisoformat(e["date"]) - dt.date.today()).days
                except ValueError:
                    left = 0
                r = arow(L("%s  -  %s (%s)" % (e["subject"], e["date"], "%d days left" % left if left >= 0 else
                                               "over"), 13, size_hint_x=.8),
                         GButton("X", "soft", h=32, size_hint_x=None, width=dp(36)), min_h=36)
                r.children[0].bind(on_release=lambda *_, e=e: (APP.db.ex("DELETE FROM exams WHERE id=?", (e["id"],)),
                                                               APP.db.touch(), self.refresh()))
                col.add_widget(r)
            a = GButton("Add Exam", "soft")
            a.bind(on_release=lambda *_: APP.ask("Add Exam", [("s", "Subject", ""), ("d", "Date DD-MM-YYYY", "")],
                                                 self.add_exam))
            col.add_widget(a)

    def mk(self, i):
        b = GButton("Undo" if i["done"] else "Done", "soft", h=30, size_hint_x=None, width=dp(60))
        b.bind(on_release=lambda *_: APP.mark(i["id"], 0 if i["done"] else 1, self))
        return b

    def add_exam(self, v):
        try:
            d = dt.datetime.strptime(v["d"], "%d-%m-%Y").date()
        except ValueError:
            APP.toast("Use date format DD-MM-YYYY")
            return False
        if not v["s"]:
            APP.toast("Enter subject")
            return False
        APP.db.ex("INSERT INTO exams(subject,date) VALUES(?,?)", (v["s"][:40], d.isoformat()))
        APP.db.touch()
        self.refresh()
        APP.toast("Exam added. Regenerate routine to include it.")

    def set_tab(self, o):
        self.tab = o
        self.refresh()


class NotesS(Base):
    def build_ui(self, col):
        s, cls = APP.subject, APP.prof.get("cls", "10")
        header(col, s or "Notes")
        if not NOTES_ENABLED:                      # left empty on purpose for now (see NOTES_ENABLED at the top)
            c = Card(pad=20, spacing=6)
            c.add_widget(L("Notes", 18, bold=True, center=True))
            c.add_widget(L("Notes for this subject are coming soon.", 13, "sub", center=True))
            col.add_widget(c)
            return
        pack = CONTENT.get(cls, {}).get(s, {"chapters": []})
        key = "%s:%s" % (cls, s)
        owned = bool(APP.db.one("SELECT 1 FROM purchases WHERE kind='notes' AND ref=?", (key,)))
        if not pack["chapters"]:
            col.add_widget(L("Study material for this subject has not been added yet.", 13, "sub"))
        for ch in pack["chapters"]:
            c = TapCard(pad=10)
            lock = "" if (owned or ch.get("free")) else "  [locked]"
            c.add_widget(L(ch["title"] + lock, 14, bold=True))
            c.bind(on_release=lambda *_, ch=ch: self.open(ch, owned))
            col.add_widget(c)
        if not owned:
            b = GButton("Unlock Subject - Rs. %d" % NOTES_PRICE_INR)
            b.bind(on_release=lambda *_: APP.start_payment("notes", key, "Notes: " + s, self))
            col.add_widget(b)
        rb = GButton("Restore Purchases", "ghost")
        rb.bind(on_release=lambda *_: APP.restore_purchases(self))
        col.add_widget(rb)

    def open(self, ch, owned):
        if not (owned or ch.get("free")):
            return APP.toast("Unlock the subject to read this chapter")
        APP.dialog(ch["title"], [L(ch.get("notes", "") + "\n\nPYQ:\n" + ch.get("pyq", "-"), 13)], [("Close", None, "soft")])


# ---------- Diet ----------
COMMON_FOOD = ["Poha", "Rice", "Dal", "Roti", "Vegetables", "Milk", "Fruits", "Eggs", "Paneer", "Curd", "Oats", "Bread"]


class DietS(Base):
    nav_tab = "Diet"
    tab = "Today"

    def build_ui(self, col):
        p = APP.prof
        header(col, t("Diet Planner"), back=False)
        col.add_widget(seg(["Today", "Ingredients", "Saved"], self.tab, self.set_tab))
        if self.tab == "Today":
            meals = [i for i in APP.routine_for(dt.date.today()) if i["category"] == "meal"]
            m = APP.db.get("meals") or {}
            c = Card()
            c.add_widget(L("Today's Meals", 15, bold=True))
            if not meals and not m.get("meals"):
                c.add_widget(L("No meals yet. Add ingredients and tap Suggest Meals.", 12, "sub"))
            for i in meals:
                c.add_widget(L("%s  %s" % (fmt_min(i["start"]), i["title"]), 13))
            col.add_widget(c)
            for i, ml in enumerate(m.get("meals", [])):
                mc = Card(pad=10, spacing=3)
                mc.add_widget(L("%s %s" % (ml["type"].title(), ("• " + fmt_min(parse_time(ml["time"]))) if ml["time"] else ""),
                                12, "green"))
                mc.add_widget(L(ml["name"], 14, bold=True))
                mc.add_widget(L(", ".join(ml["items"]), 12, "sub"))
                if ml["note"]:
                    mc.add_widget(L(ml["note"], 11, "sub"))
                r = BoxLayout(size_hint_y=None, height=dp(34), spacing=dp(6))
                for txt, fn in (("Save", lambda ml=ml: self.save_meal(ml)),
                                ("Replace", lambda ml=ml: self.suggest(ml["type"]))):
                    b = GButton(txt, "soft", h=34, font_size=sp(12))
                    b.bind(on_release=lambda *_, f=fn: f())
                    r.add_widget(b)
                mc.add_widget(r)
                col.add_widget(mc)
            for w in m.get("warnings", []):
                col.add_widget(L("• " + w, 11, "sub"))
            b = GButton("Suggest Meals")
            b.bind(on_release=lambda *_: self.suggest(None))
            col.add_widget(b)
            col.add_widget(L("General food ideas only - not medical or prescribed diet advice.", 11, "sub"))
            wc = Card()
            ml_ = APP.water_today()
            wc.add_widget(L("%s: %d ml today" % (t("Water Intake"), ml_), 14, bold=True))
            r = BoxLayout(size_hint_y=None, height=dp(38), spacing=dp(6))
            for a in (150, 250, 500):
                b = GButton("+%d" % a, "soft", h=38)
                b.bind(on_release=lambda *_, a=a: (APP.add_water(a), self.refresh()))
                r.add_widget(b)
            wc.add_widget(r)
            col.add_widget(wc)
        elif self.tab == "Ingredients":
            col.add_widget(L("What's available at home?", 14, bold=True))
            have = p.get("ingredients", [])
            allf = COMMON_FOOD + [f for f in have if f not in COMMON_FOOD]
            g, self.cs = chips(allf, have, None, 3, 38)
            col.add_widget(g)
            self.custom = Field("Add custom food item")
            col.add_widget(self.custom)
            r = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
            a = GButton("Add Food", "soft", h=44)
            a.bind(on_release=lambda *_: self.add_food())
            s = GButton("Save List", h=44)
            s.bind(on_release=lambda *_: self.save_ing())
            r.add_widget(a)
            r.add_widget(s)
            col.add_widget(r)
            self.allergy = Field("Allergies", p.get("allergies", ""))
            col.add_widget(L("Allergy information (AI will never use these)", 12, "sub"))
            col.add_widget(self.allergy)
        else:
            sv = APP.db.all("SELECT * FROM saved WHERE kind='meal'")
            if not sv:
                col.add_widget(L("No saved meals.", 12, "sub"))
            for s in sv:
                d = json.loads(s["data"])
                r = arow(L("%s: %s" % (d["type"].title(), d["name"]), 13, size_hint_x=.8),
                         GButton("X", "soft", h=32, size_hint_x=None, width=dp(36)), min_h=36)
                r.children[0].bind(on_release=lambda *_, s=s: (APP.db.ex("DELETE FROM saved WHERE id=?", (s["id"],)),
                                                               self.refresh()))
                col.add_widget(r)

    def set_tab(self, o):
        self.tab = o
        self.refresh()

    def add_food(self):
        f = self.custom.val
        if f:
            APP.prof.setdefault("ingredients", []).append(f[:30])
            APP.save_prof()
            self.refresh()

    def save_ing(self):
        APP.prof["ingredients"] = picked(self.cs)
        APP.prof["allergies"] = self.allergy.val
        APP.save_prof()
        APP.toast("Saved")

    def save_meal(self, ml):
        APP.db.ex("INSERT INTO saved(kind,data) VALUES('meal',?)", (json.dumps(ml),))
        APP.db.touch()
        APP.toast("Meal saved")

    def suggest(self, only):
        if not APP.prof.get("ingredients"):
            return APP.toast("Add available ingredients first")

        def ok(r):
            cur = APP.db.get("meals") or {"meals": []}
            if only:
                new = [m for m in r["meals"] if m["type"] == only] or r["meals"][:1]
                cur["meals"] = [m for m in cur["meals"] if m["type"] != only] + new
            else:
                cur["meals"] = r["meals"]
            cur["warnings"] = r["warnings"]
            APP.db.put("meals", cur)
            APP.db.touch()
            self.refresh()
        APP.bg(lambda: APP.ai("meals", {"profile": APP.ai_profile("meals")}), ok)


# ---------- Workout ----------
class WorkoutS(Base):
    nav_tab = "Fitness"
    tab = "Today"

    def build_ui(self, col):
        header(col, t("Workout Plan"), back=False)
        col.add_widget(seg(["Today", "Weekly", "History"], self.tab, self.set_tab))
        if self.tab == "Today":
            w = APP.db.get("workout")
            c = Card()
            if w and w.get("exercises"):
                c.add_widget(L(w["title"], 17, bold=True))
                c.add_widget(L("%d min total" % w["minutes"], 12, "sub"))
                for e in w["exercises"]:
                    c.add_widget(L("%s  (%d min)" % (e["name"], e["minutes"]), 14, bold=True))
                    c.add_widget(L(e["instruction"], 12, "sub"))
                    if e["caution"]:
                        c.add_widget(L("Caution: " + e["caution"], 11, "sub"))
                for x in w.get("warnings", []):
                    c.add_widget(L("• " + x, 11, "sub"))
                b = GButton("Start Workout")
                b.bind(on_release=lambda *_: APP.run_timer(w["title"], w["minutes"], lambda: self.finish(w)))
                c.add_widget(b)
                r = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
                for txt, fn in (("Mark Completed", lambda: self.finish(w)), ("Replace Exercises", self.gen)):
                    bb = GButton(txt, "soft", h=40)
                    bb.bind(on_release=lambda *_, f=fn: f())
                    r.add_widget(bb)
                c.add_widget(r)
            else:
                c.add_widget(L("No workout planned yet.", 14))
                b = GButton("Generate Workout")
                b.bind(on_release=lambda *_: self.gen())
                c.add_widget(b)
            col.add_widget(c)
            col.add_widget(L("Safety: stop if you feel pain or dizziness. This is general guidance, not medical advice.",
                             11, "sub"))
            wc = Card()
            wc.add_widget(L("%s: %d ml today" % (t("Water Intake"), APP.water_today()), 14, bold=True))
            b = GButton("+250 ml", "soft", h=38)
            b.bind(on_release=lambda *_: (APP.add_water(250), self.refresh()))
            wc.add_widget(b)
            col.add_widget(wc)
        elif self.tab == "Weekly":
            col.add_widget(L("Workout sessions - last 7 days", 13, "sub"))
            vals, labs = [], GridLayout(cols=7, size_hint_y=None, height=dp(18))
            for off in range(-6, 1):
                d = (dt.date.today() + dt.timedelta(days=off)).isoformat()
                n = APP.db.one("SELECT COUNT(*) c FROM wlog WHERE date=?", (d,))["c"]
                vals.append(min(n, 1))
                labs.add_widget(L((dt.date.today() + dt.timedelta(days=off)).strftime("%a"), 10, "sub", center=True))
            col.add_widget(Bars(vals))
            col.add_widget(labs)
        else:
            h = APP.db.all("SELECT * FROM wlog ORDER BY id DESC LIMIT 30")
            if not h:
                col.add_widget(L("No completed activities yet.", 12, "sub"))
            for x in h:
                col.add_widget(L("%s - %s (%d min)" % (x["date"], x["name"], x["minutes"]), 13))

    def set_tab(self, o):
        self.tab = o
        self.refresh()

    def gen(self):
        APP.bg(lambda: APP.ai("workout", {"profile": APP.ai_profile("workout")}),
                lambda r: (APP.db.put("workout", r), APP.db.touch(), self.refresh()))

    def finish(self, w):
        APP.db.ex("INSERT INTO wlog(date,name,minutes) VALUES(?,?,?)", (dt.date.today().isoformat(), w["title"], w["minutes"]))
        APP.db.touch()
        APP.toast("Workout logged. Great job!")
        self.refresh()


# ---------- Notifications ----------
class NotifS(Base):
    tab = "All"

    def build_ui(self, col):
        header(col, t("Notifications"))
        col.add_widget(seg(["All", "Study", "Fitness", "Diet", "Settings"], self.tab, self.set_tab))
        st = APP.settings
        if self.tab == "Settings":
            def sw(label, key, sub=None):
                s = Switch(active=(st.get(key) if sub is None else st["cats"].get(sub, True)),
                           size_hint=(None, None), size=(dp(80), dp(40)))
                s.bind(active=lambda i, v: self.setv(key, v, sub))
                col.add_widget(hrow(44, L(label, 14), s))
            sw("Enable reminders", "remind")
            for c_ in ("Study", "Fitness", "Diet", "Water", "Bedtime"):
                sw(c_ + " reminders", "cats", c_)
            q1, q2 = Field("Quiet from", st["quiet_from"]), Field("Quiet to", st["quiet_to"])
            wev = Field("Water reminder every N minutes", str(st["water_every"]), filt="int")
            col.add_widget(L("Quiet hours (no reminders)", 12, "sub"))
            col.add_widget(hrow(48, q1, q2))
            col.add_widget(wev)
            b = GButton("Save")
            b.bind(on_release=lambda *_: self.save_q(q1, q2, wev))
            col.add_widget(b)
            col.add_widget(L("Reminders are shown while Study Fit is running in the background.", 11, "sub"))
        else:
            rows = APP.db.all("SELECT * FROM notif ORDER BY ts DESC LIMIT 60")
            if self.tab != "All":
                rows = [r for r in rows if r["cat"] == self.tab]
            if not rows:
                col.add_widget(L("No notifications yet.", 13, "sub"))
            for r in rows:
                c = Card(pad=10, spacing=2)
                c.add_widget(L(r["title"], 14, bold=True))
                c.add_widget(L(r["body"] + "  •  " + dt.datetime.fromtimestamp(r["ts"]).strftime("%d %b %I:%M %p"),
                               11, "sub"))
                col.add_widget(c)

    def set_tab(self, o):
        self.tab = o
        self.refresh()

    def setv(self, key, v, sub):
        if sub is None:
            APP.settings[key] = v
        else:
            APP.settings["cats"][sub] = v
        APP.db.put("settings", APP.settings)

    def save_q(self, q1, q2, wev):
        if parse_time(q1.val) is None or parse_time(q2.val) is None:
            return APP.toast("Invalid quiet hours")
        APP.settings.update(quiet_from=q1.val, quiet_to=q2.val, water_every=max(30, int(wev.val or 90)))
        APP.db.put("settings", APP.settings)
        APP.toast("Saved")


# ---------- Progress ----------
class ProgressS(Base):
    tab = "This Week"

    def build_ui(self, col):
        header(col, t("Progress"))
        col.add_widget(seg(["This Week", "This Month", "All Time"], self.tab, self.set_tab))
        n = {"This Week": 7, "This Month": 30, "All Time": 3650}[self.tab]
        since = (dt.date.today() - dt.timedelta(days=n - 1)).isoformat()
        rt = APP.db.all("SELECT * FROM routine WHERE date>=? AND date<=? AND category NOT IN ('school','sleep')",
                        (since, dt.date.today().isoformat()))
        done = sum(1 for r in rt if r["done"])
        c = Card()
        ring = Ring()
        ring.v = done / len(rt) if rt else 0
        c.add_widget(hrow(104, ring, L("Overall routine completion\n%d of %d tasks" % (done, len(rt)), 13, "sub")))
        col.add_widget(c)
        st = [r for r in rt if r["category"] in ("study", "revision")]
        gr = GridLayout(cols=2, spacing=dp(8), size_hint_y=None)
        gr.bind(minimum_height=gr.setter("height"))
        wk = APP.db.one("SELECT COUNT(*) c FROM wlog WHERE date>=?", (since,))["c"]
        wd = APP.db.one("SELECT COUNT(*) c FROM water WHERE date>=? AND ml>0", (since,))["c"]
        for lab, val in (("Workouts", wk), ("Meals done", sum(1 for r in rt if r["category"] == "meal" and r["done"])),
                         ("Study sessions", "%d/%d" % (sum(1 for r in st if r["done"]), len(st))),
                         ("Days water logged", wd)):
            cc = Card(pad=10, spacing=2)
            cc.size_hint_y = None
            cc.add_widget(L(str(val), 20, bold=True, col="green"))
            cc.add_widget(L(lab, 11, "sub"))
            gr.add_widget(cc)
        col.add_widget(gr)
        col.add_widget(L("Weekly Activity (tasks completed per day)", 13, "sub"))
        vals, labs = [], GridLayout(cols=7, size_hint_y=None, height=dp(18))
        for off in range(-6, 1):
            d = dt.date.today() + dt.timedelta(days=off)
            its = [i for i in APP.routine_for(d) if i["category"] not in ("school", "sleep")]
            vals.append(sum(1 for i in its if i["done"]) / len(its) if its else 0)
            labs.add_widget(L(d.strftime("%a"), 10, "sub", center=True))
        col.add_widget(Bars(vals))
        col.add_widget(labs)
        b = GButton("Weight Progress", "out")
        b.bind(on_release=lambda *_: APP.go("weight"))
        col.add_widget(b)

    def set_tab(self, o):
        self.tab = o
        self.refresh()


# ---------- Weight ----------
class WeightS(Base):
    rng = "Weekly"

    def build_ui(self, col):
        u = APP.prof.get("unit", "kg")
        header(col, "Weight Tracking")
        col.add_widget(seg(["Weekly", "Monthly", "All"], self.rng, self.set_r))
        n = {"Weekly": 7, "Monthly": 30, "All": 36500}[self.rng]
        since = (dt.date.today() - dt.timedelta(days=n)).isoformat()
        rows = APP.db.all("SELECT * FROM weights WHERE date>=? ORDER BY date, id", (since,))
        conv = (lambda k: k * 2.20462) if u == "lb" else (lambda k: k)
        if len(rows) >= 2:
            col.add_widget(LineChart([conv(r["kg"]) for r in rows]))
            d = conv(rows[-1]["kg"]) - conv(rows[0]["kg"])
            col.add_widget(L("Change in this period: %+.1f %s (neutral view - not a score)" % (d, u), 12, "sub"))
        elif rows:
            col.add_widget(L("Add one more entry to see a trend.", 12, "sub"))
        else:
            col.add_widget(L("No entries yet.", 12, "sub"))
        self.f = Field("New weight in " + u, filt="float")
        col.add_widget(self.f)
        b = GButton("Add New Weight Entry")
        b.bind(on_release=lambda *_: (APP.add_weight(self.f.val, u) and self.refresh()))
        col.add_widget(b)
        for r in reversed(rows[-30:]):
            row = arow(L("%s   %.1f %s" % (r["date"], conv(r["kg"]), u), 13, size_hint_x=.6),
                       GButton("Edit", "soft", h=30, size_hint_x=None, width=dp(52)),
                       GButton("X", "soft", h=30, size_hint_x=None, width=dp(36)), min_h=34)
            row.children[1].bind(on_release=lambda *_, r=r: APP.ask("Edit entry", [("w", "Weight in " + u, "%.1f" % conv(r["kg"]))],
                                                                    lambda v, r=r: self.edit(r, v["w"], u)))
            row.children[0].bind(on_release=lambda *_, r=r: (APP.db.ex("DELETE FROM weights WHERE id=?", (r["id"],)),
                                                             APP.db.touch(), self.refresh()))
            col.add_widget(row)

    def edit(self, r, w, u):
        try:
            kg = float(w) / (2.20462 if u == "lb" else 1)
            assert 15 <= kg <= 300
        except Exception:
            APP.toast("Enter a realistic weight")
            return False
        APP.db.ex("UPDATE weights SET kg=? WHERE id=?", (kg, r["id"]))
        APP.db.touch()
        self.refresh()

    def set_r(self, o):
        self.rng = o
        self.refresh()


# ---------- Store ----------
class StoreS(Base):
    def build_ui(self, col):
        header(col, "Study Fit Store")
        minor = (APP.prof.get("age") or 18) < 18
        prods = [p for p in STORE_PRODUCTS if not (minor and p.get("category") == "supplement")]
        if not prods:
            c = Card(pad=20, spacing=6)
            c.add_widget(L("Study Fit Store", 18, bold=True, center=True))
            c.add_widget(L("Fitness and study products are coming soon.", 13, "sub", center=True))
            col.add_widget(c)
        for p in prods:
            c = Card()
            img = asset("products/%s.png" % p["id"])
            if img:
                c.add_widget(Image(source=img, size_hint_y=None, height=dp(120), fit_mode="contain"))
            c.add_widget(L(p["name"], 15, bold=True))
            c.add_widget(L("%s • %s" % (p.get("brand", ""), p.get("seller", "")), 11, "sub"))
            c.add_widget(L(p.get("desc", ""), 12, "sub"))
            b = GButton("Buy - Rs. %d" % p["price"])
            b.bind(on_release=lambda *_, p=p: APP.start_payment("product", p["id"], p["name"], self))
            c.add_widget(b)
            col.add_widget(c)
        col.add_widget(L("Supplements are not medical treatment and are never recommended to under-18 users.", 11, "sub"))


# ---------- Settings ----------
class SettingsS(Base):
    nav_tab = "Profile"

    def build_ui(self, col):
        p = APP.prof
        header(col, t("Settings"), back=False)
        c = Card()
        c.add_widget(arow(avatar(54), vbox_of(L(p.get("name", ""), 16, bold=True),
                                              L(APP.sess.get("email", "") or APP.sess.get("phone", ""), 12, "sub")),
                          min_h=60))
        col.add_widget(c)

        def row(title, val="", fn=None):
            tc = TapCard(pad=12, spacing=2)
            tc.add_widget(arow(L(title, 14, size_hint_x=.6), L(val, 12, "sub"), min_h=24))
            tc.bind(on_release=lambda *_: fn and fn())
            col.add_widget(tc)
        row("Account & Security", "", self.account)
        row(t("Notifications"), "", lambda: APP.go("notif"))
        dm = Switch(active=APP.settings.get("dark", True), size_hint=(None, None), size=(dp(80), dp(40)))
        dm.bind(active=lambda i, v: APP.set_dark(v))
        col.add_widget(hrow(44, L("Dark Mode", 14), dm))
        row("Language", lang_name(p.get("lang", "en")), lambda: APP.go("lang"))
        row("Data & Backup", "Synced: " + APP.last_sync_txt(), lambda: APP.sync(manual=True))
        row("Edit Profile & Schedule", "", lambda: APP.go("p_personal"))
        row("Weight Tracking", "", lambda: APP.go("weight"))
        row("Study Fit Store", "", lambda: APP.go("store"))
        row("Help & Support", SUPPORT_EMAIL, lambda: open_url("mailto:" + SUPPORT_EMAIL))
        row("Terms of Service", "", lambda: open_url(TERMS_URL))
        row("Privacy Policy", "", lambda: open_url(PRIVACY_URL))
        row("About Study Fit", "v" + APP_VERSION, lambda: APP.toast("Study Fit v" + APP_VERSION))
        lo = GButton(t("Log Out"), "out")
        lo.bind(on_release=lambda *_: APP.confirm("Log out? Local data on this device will be cleared "
                                                  "(your cloud backup stays).", APP.logout))
        col.add_widget(lo)
        da = GButton(t("Delete Account"), "danger")
        da.bind(on_release=lambda *_: APP.confirm("Permanently delete your account and ALL data? "
                                                  "This cannot be undone.", APP.delete_account))
        col.add_widget(da)

    def account(self):
        APP.dialog("Account & Security", [L(APP.sess.get("email") or APP.sess.get("phone") or "", 13, "sub")], [
            ("Send verification email", lambda: APP.send_verify_mail(), "soft"),
            ("Change password (email link)", lambda: APP.bg(
                lambda: fb_oob("PASSWORD_RESET", email=APP.sess["email"]),
                lambda r: APP.toast("Reset link sent")) if APP.sess.get("email") else APP.toast("No email on account"),
             "soft"),
            ("Add / verify mobile", lambda: APP.otp_link(), "soft"), ("Close", None, "ghost")])


def vbox_of(*ws):
    v = vbox(2)
    for w in ws:
        v.add_widget(w)
    return v


# =====================================================================
#  APP CLASS
# =====================================================================
class StudyFitApp(App):
    title = APP_NAME

    # ---------- lifecycle ----------
    def build(self):
        global APP
        APP = self
        if platform != "android":
            Window.size = (390, 800)
        Window.softinput_mode = "below_target"
        self.db = DB(os.path.join(self.user_data_dir, "studyfit.db"))
        self.prof = self.db.get("profile", {}) or {}
        self.settings = self.db.get("settings") or dict(
            remind=True, dark=True, quiet_from="10:30 PM", quiet_to="6:00 AM", water_every=90,
            cats={"Study": True, "Fitness": True, "Diet": True, "Water": True, "Bedtime": True})
        self.sess = self.db.get("session", {}) or {}
        self.otp, self.hist, self.subject = {}, [], ""
        register_fonts()
        set_theme(self.settings.get("dark", True))
        self.sm = ScreenManager(transition=SlideTransition(duration=.18))
        for name, cls in (("splash", SplashS), ("lang", LangS), ("welcome", WelcomeS), ("signup", SignupS),
                          ("otp", OtpS), ("backup", BackupS), ("p_personal", PersonalS), ("p_weight", WeightSetupS),
                          ("p_goals", GoalsS), ("p_life", LifeS), ("p_review", ReviewS), ("home", HomeS),
                          ("routine", RoutineS), ("study", StudyS), ("notes", NotesS), ("diet", DietS),
                          ("workout", WorkoutS), ("notif", NotifS), ("progress", ProgressS), ("weight", WeightS),
                          ("store", StoreS), ("settings", SettingsS)):
            self.sm.add_widget(cls(name=name))
        Window.bind(on_keyboard=self.on_key)
        Clock.schedule_interval(self.tick, 20)
        self.ask_android_perms()
        return self.sm

    def ask_android_perms(self):
        if platform == "android":
            try:
                from android.permissions import request_permissions
                request_permissions(["android.permission.POST_NOTIFICATIONS"])
            except Exception:
                pass

    def after_splash(self):
        if self.sess.get("uid") and self.prof.get("setup_done"):
            self.go("home", root=True)
            self.sync_bg()
        elif self.sess.get("uid"):
            self.go("p_personal", root=True)
        elif not self.db.get("lang_chosen"):
            self.go("lang", root=True)
        else:
            self.go("welcome", root=True)

    def on_pause(self):
        return True            # Android: keep the app alive while the browser is open (Google login / payment)

    def on_resume(self):
        pass

    def on_key(self, w, key, *a):
        if key == 27:
            if len(self.hist) > 0:
                self.back()
                return True
        return False

    # ---------- navigation ----------
    def go(self, name, root=False):
        cur = self.sm.current
        if root:
            self.hist = []
            self.sm.transition.direction = "left"
        else:
            if cur != name:
                self.hist.append(cur)
            self.sm.transition.direction = "left"
        self.sm.current = name

    def back(self):
        if self.hist:
            self.sm.transition.direction = "right"
            self.sm.current = self.hist.pop()

    def set_dark(self, v):
        self.settings["dark"] = v
        self.db.put("settings", self.settings)
        set_theme(v)
        self.sm.get_screen(self.sm.current).refresh()

    # ---------- UI helpers ----------
    def toast(self, msg, sec=2.8):
        lab = Label(text=msg, font_size=sp(13), color=(1, 1, 1, 1), size_hint=(None, None), font_name=cur_font(),
                    halign="center", valign="middle")
        lab.text_size = (Window.width * .8, None)
        lab.texture_update()
        lab.size = (min(Window.width * .86, lab.texture_size[0] + dp(28)), lab.texture_size[1] + dp(20))
        lab.pos = ((Window.width - lab.width) / 2, dp(90))
        with lab.canvas.before:
            Color(.1, .15, .3, .96)
            RoundedRectangle(pos=lab.pos, size=lab.size, radius=[dp(14)])
        Window.add_widget(lab)
        Clock.schedule_once(lambda *_: Window.remove_widget(lab), sec)

    def show_busy(self, on):
        if on and not getattr(self, "_busy", None):
            mv = ModalView(size_hint=(None, None), size=(dp(200), dp(90)), auto_dismiss=False,
                           background="", background_color=(0, 0, 0, .75))
            mv.add_widget(Label(text="Please wait...", font_name=cur_font()))
            mv.open()
            self._busy = mv
        elif not on and getattr(self, "_busy", None):
            self._busy.dismiss()
            self._busy = None

    def dialog(self, title, widgets, buttons):
        mv = ModalView(size_hint=(.92, None), auto_dismiss=True, background="", background_color=(0, 0, 0, .6))
        card = Card(pad=16, spacing=10)
        card.add_widget(L(title, 17, bold=True))
        for w in widgets:
            card.add_widget(w)
        for txt, cb, kind in buttons:
            b = GButton(txt, kind or "grad", h=44)

            def h(*_, cb=cb):
                if cb and cb() is False:
                    return
                mv.dismiss()
            b.bind(on_release=h)
            card.add_widget(b)
        sv = ScrollView(do_scroll_x=False, bar_width=dp(2))     # tall dialogs scroll instead of being cut off
        sv.add_widget(card)
        mv.add_widget(sv)

        def fit(*_):
            mv.height = min(card.height, Window.height * .9)
        card.bind(height=fit)
        fit()
        mv.open()
        Clock.schedule_once(fit, .05)
        return mv

    def ask(self, title, fields, ok):
        fs = {}
        ws = []
        for key, hint, default in fields:
            f = Field(hint, default)
            fs[key] = f
            ws.append(f)
        self.dialog(title, ws, [("Save", lambda: ok({k: f.val for k, f in fs.items()}), "grad"),
                                (t("Cancel"), None, "ghost")])

    def confirm(self, msg, yes):
        self.dialog("Please confirm", [L(msg, 13, "sub")], [("Yes", yes, "danger"), (t("Cancel"), None, "ghost")])

    def human_err(self, e):
        m = e.msg or ""
        for k, v in ERR.items():
            if k in m:
                return v
        return "Something went wrong: " + m[:120]

    def bg(self, fn, ok=None, busy=True, on_err=None):
        if busy:
            self.show_busy(True)

        def work():
            r, err = None, None
            try:
                r = fn()
            except ApiError as e:
                err = e
            except Exception as e:
                err = ApiError(str(e), -1)

            def done(*_):
                if busy:
                    self.show_busy(False)
                if err:
                    if on_err:
                        on_err(err)
                    else:
                        self.toast(self.human_err(err))
                elif ok:
                    ok(r)
            Clock.schedule_once(done)
        threading.Thread(target=work, daemon=True).start()

    # ---------- profile ----------
    def save_prof(self):
        self.db.put("profile", self.prof)
        self.db.touch()

    # ---------- auth ----------
    def on_login(self, r, ident, new=False, name=None):
        ident = ident or ""
        try:
            exp = time.time() + int(r.get("expiresIn", 3600))
        except (TypeError, ValueError):
            exp = time.time() + 3600
        self.sess = dict(uid=r["localId"], email=r.get("email", ident) if "@" in str(ident) else "",
                         phone=ident if ident and "@" not in str(ident) else "", idToken=r["idToken"],
                         refreshToken=r["refreshToken"], exp=exp)
        self.db.put("session", self.sess)

        def keep_name():
            if name and not self.prof.get("name"):
                self.prof["name"] = name
                self.save_prof()
        if new:
            keep_name()
            self.go("backup", root=True)
            return

        def pull():
            try:
                return fs_get(self.sess["uid"], self.sess["idToken"])
            except ApiError:
                return None            # new account / Firestore not ready yet -> start fresh, never block login

        def ok(doc):
            if doc and doc["ts"] >= self.db.get("mod", 0):
                self.db.import_(doc["data"])
                self.prof = self.db.get("profile", {}) or {}
                self.settings = self.db.get("settings") or self.settings
                self.db.put("last_sync", int(time.time()))
            keep_name()
            self.after_splash()
        self.bg(pull, ok)

    def ensure_token(self):
        if time.time() > self.sess.get("exp", 0) - 60:
            r = fb_refresh(self.sess["refreshToken"])
            self.sess.update(idToken=r["id_token"], refreshToken=r["refresh_token"],
                             exp=time.time() + int(r["expires_in"]))
            self.db.put("session", self.sess)
        return self.sess["idToken"]

    def social_login(self, which):
        """Google / Facebook login (Firebase). The phone browser opens a sign-in page served by YOUR
        backend (see login_page_html); the app polls the backend until the login is finished.
        One-time setup is listed next to FIREBASE_WEB_CONFIG at the top of this file."""
        if not BACKEND_URL:
            return self.toast("Google login needs your Study Fit server. Set BACKEND_URL in main.py "
                              "(email login works without it).")
        if getattr(self, "_soc", None) and not self._soc["stop"]:
            self._soc["stop"] = True                     # a previous attempt is still polling - cancel it
        st = self._soc = {"sid": secrets.token_urlsafe(24), "stop": False, "cancel": False, "mv": None}
        if not open_url("%s/auth/%s?sid=%s" % (BACKEND_URL, which, st["sid"])):
            st["stop"] = True
            return self.toast("Could not open the browser. Please try again.")

        def cancel():
            st["stop"] = st["cancel"] = True
        st["mv"] = self.dialog("Sign in with " + which.title(),
                               [L("Finish the sign-in in your browser, then come back to Study Fit. "
                                  "Waiting...", 13, "sub")], [("Cancel", cancel, "ghost")])
        st["mv"].bind(on_dismiss=lambda *_: cancel() if not st.get("done") else None)
        threading.Thread(target=self._soc_poll, args=(st,), daemon=True).start()

    def _soc_poll(self, st):
        t0 = time.time()
        while not st["stop"] and time.time() - t0 < 240:
            time.sleep(2.5)
            if st["stop"]:
                return
            try:
                r = http_json("POST", BACKEND_URL + "/auth/poll", {"sid": st["sid"]}, timeout=15)
            except ApiError as e:
                if e.code == 429:
                    time.sleep(5)
                continue                                 # offline for a moment - keep waiting
            if r.get("status") == "done" and isinstance(r.get("result"), dict):
                st["stop"] = st["done"] = True
                res = r["result"]
                Clock.schedule_once(lambda *_: self._soc_done(st, res))
                return
        if not st["cancel"] and not st.get("done"):
            st["stop"] = True
            Clock.schedule_once(lambda *_: (st["mv"] and st["mv"].dismiss(),
                                            self.toast("Sign-in timed out. Please try again.")))

    def _soc_done(self, st, res):
        if st["mv"]:
            st["mv"].dismiss()
        if not (res.get("localId") and res.get("idToken") and res.get("refreshToken")):
            return self.toast("Login failed. Please try again.")
        self.on_login(res, res.get("email", ""), name=(res.get("displayName") or "").strip() or None)

    def send_verify_mail(self):
        if not self.sess.get("email"):
            return self.toast("Login with email to verify it")
        self.bg(lambda: fb_oob("VERIFY_EMAIL", idToken=self.ensure_token()),
                 lambda r: self.toast("Verification link sent to your email"))

    # ---------- OTP ----------
    def otp_start(self, phone, mode):
        self.otp = dict(phone=phone, mode=mode, until=0)
        self.otp_send(phone, mode, silent=True)

    def otp_link(self):
        self.ask("Add mobile number", [("p", "+91XXXXXXXXXX", "+91")],
                 lambda v: self.otp_start(v["p"], "link") if re.match(r"^\+\d{10,14}$", v["p"]) else
                 (self.toast("Use +91XXXXXXXXXX"), False)[1])

    def otp_send(self, phone, mode, silent=True):
        if not BACKEND_URL:
            return self.toast("Mobile OTP is not available yet. Please use email or Google login.")
        if self.otp.get("until", 0) > time.time():
            return self.toast("Please wait before resending")

        def ok(r):
            self.otp["until"] = time.time() + 45
            if self.sm.current != "otp":
                self.go("otp")
            else:
                self.sm.get_screen("otp").refresh()
            self.toast("OTP sent")
        self.bg(lambda: http_json("POST", BACKEND_URL + "/otp/send", {"phone": phone}), ok)

    def otp_verify(self, code):
        phone, link = self.otp["phone"], self.otp.get("mode") == "link"

        def work():
            h = {"Authorization": "Bearer " + self.ensure_token()} if link else None
            r = http_json("POST", BACKEND_URL + "/otp/verify", {"phone": phone, "code": code}, h)
            if r.get("linked"):
                return {"linked": True}
            return fb_sign_in_custom(r["customToken"])          # network call stays in the worker thread

        def ok(res):
            if res.get("linked"):
                self.toast("Mobile number linked")
                self.back()
                return
            self.on_login(res, phone, new=not self.prof.get("setup_done"))
        self.bg(work, ok)

    # ---------- cloud sync ----------
    def last_sync_txt(self):
        ts = self.db.get("last_sync")
        return dt.datetime.fromtimestamp(ts).strftime("%d %b, %I:%M %p") if ts else "never"

    def sync_bg(self):
        self.sync(manual=False)

    def _sync_work(self):
        tok = self.ensure_token()
        doc = fs_get(self.sess["uid"], tok)
        local = self.db.get("mod", 0)
        if doc and doc["ts"] > local:            # last-writer-wins by timestamp
            self.db.import_(doc["data"])
            return "pulled"
        fs_put(self.sess["uid"], tok, self.db.export(), max(local, int(time.time())))
        return "pushed"

    def sync(self, manual=True):
        if not self.sess.get("uid"):
            return manual and self.toast("Login to sync")

        def ok(r):
            self.db.put("last_sync", int(time.time()))
            if r == "pulled":
                self.prof = self.db.get("profile", {}) or {}
            if manual:
                self.toast("Synced (%s)" % r)
        self.bg(self._sync_work, ok, busy=manual)

    def logout(self):
        """Back up FIRST (waits for the upload), only then wipe this device."""
        if not self.sess.get("uid"):
            return self._leave()
        self.bg(self._sync_work, lambda r: self._leave(),
                 on_err=lambda e: self.confirm("Could not back up your data (%s). Log out anyway? Data not yet "
                                               "backed up will be lost from this device." % self.human_err(e),
                                               self._leave))

    def _leave(self):
        self.db.wipe()
        self.prof, self.sess = {}, {}
        self.go("welcome", root=True)

    def delete_account(self):
        def work():
            tok = self.ensure_token()
            fs_del(self.sess["uid"], tok)
            fb_delete(tok)
        # NOTE: also delete server-side records (payments) on your backend if you store personal data there.

        def ok(_):
            self.db.wipe()
            self.prof, self.sess = {}, {}
            self.toast("Account deleted")
            self.go("welcome", root=True)
        self.bg(work, ok)

    # ---------- data helpers ----------
    def add_weight(self, val, unit):
        try:
            kg = float(val) / (2.20462 if unit == "lb" else 1)
            assert 15 <= kg <= 300
        except Exception:
            self.toast("Enter a realistic weight")
            return False
        self.db.ex("INSERT INTO weights(date,kg) VALUES(?,?)", (dt.date.today().isoformat(), kg))
        self.db.touch()
        return True

    def routine_for(self, day):
        return self.db.all("SELECT * FROM routine WHERE date=? ORDER BY start, end", (day.isoformat() if hasattr(day, "isoformat") else day,))

    def clash(self, date_iso, s, e, ignore=None):
        for r in self.db.all("SELECT * FROM routine WHERE date=?", (date_iso,)):
            if r["id"] != ignore and r["category"] != "sleep" and s < r["end"] and e > r["start"]:
                return r["title"]
        return None

    def mark(self, rid, v, screen=None):
        self.db.ex("UPDATE routine SET done=? WHERE id=?", (v, rid))
        self.db.touch()
        if screen:
            screen.refresh()

    def water_today(self):
        r = self.db.one("SELECT ml FROM water WHERE date=?", (dt.date.today().isoformat(),))
        return r["ml"] if r else 0

    def add_water(self, ml):
        d = dt.date.today().isoformat()
        self.db.ex("INSERT INTO water(date,ml) VALUES(?,?) ON CONFLICT(date) DO UPDATE SET ml=ml+?", (d, ml, ml))
        self.db.touch()
        self.toast("Water logged: %d ml today" % self.water_today())

    # ---------- timers ----------
    def run_timer(self, title, minutes, on_done):
        st = {"left": int(minutes * 60), "run": True}
        lab = L("", 36, bold=True, center=True)

        def show():
            lab.text = "%02d:%02d" % divmod(st["left"], 60)
        show()

        def tick(*_):
            if st["run"] and st["left"] > 0:
                st["left"] -= 1
                show()
            if st["left"] == 0:
                ev.cancel()
                self.toast("Time's up!")
        ev = Clock.schedule_interval(tick, 1)
        pb = GButton("Pause", "soft", h=44)

        def tp(*_):
            st["run"] = not st["run"]
            pb.text = "Pause" if st["run"] else "Resume"
        pb.bind(on_release=tp)
        mv = self.dialog(title, [lab, pb], [("Finish", lambda: (ev.cancel(), on_done()), "grad"),
                                           ("Cancel / Skip", lambda: ev.cancel(), "ghost")])
        mv.bind(on_dismiss=lambda *_: ev.cancel())

    # ---------- AI ----------
    def ai_profile(self, kind):
        """Data minimisation: only what this request needs. Name/DOB/contacts are NEVER sent."""
        p, g = self.prof, self.prof.get("goals", [])
        age = p.get("age") or 16
        d = dict(age_group="under_18" if age < 18 else "18_plus", wake=p.get("wake"), sleep=p.get("sleep"))
        want_study = kind == "routine" and ("study" in g or "routine" in g)
        if want_study:
            exams = [dict(subject=e["subject"], date=e["date"]) for e in self.db.all(
                "SELECT * FROM exams WHERE date>=? ORDER BY date LIMIT 8", (dt.date.today().isoformat(),))]
            d.update(class_=p.get("cls"), subjects=p.get("subjects"), school_start=p.get("school_start"),
                     school_end=p.get("school_end"), study_from=p.get("study_from"), study_hours=p.get("study_hours"),
                     school_days=p.get("school_days"), exams=exams,
                     pending_homework=self.db.one("SELECT COUNT(*) c FROM homework WHERE done=0")["c"])
        if kind in ("meals", "routine") and ("diet" in g or "routine" in g):
            d.update(food_pref=p.get("food_pref"), allergies=p.get("allergies"), ingredients=p.get("ingredients"))
        if kind in ("workout", "routine") and ("fitness" in g or "routine" in g):
            d.update(workout_prefs=p.get("wprefs"), workout_time=p.get("workout_time"),
                     workout_minutes=p.get("workout_minutes", 30), experience=p.get("exp"),
                     injuries=p.get("injuries"))
            w = self.db.one("SELECT kg FROM weights ORDER BY date DESC, id DESC LIMIT 1")
            if w and kind in ("workout", "routine"):
                d["weight_kg"] = round(w["kg"], 1)      # context only; AI is told never to use it alone
        return {k: v for k, v in d.items() if v not in (None, "", [])}

    def ai(self, kind, payload):
        if BACKEND_URL:
            return http_json("POST", "%s/ai/%s" % (BACKEND_URL, kind), payload,
                             {"Authorization": "Bearer " + self.ensure_token()}, timeout=130)
        if DEV_DIRECT_GEMINI and GEMINI_API_KEY:     # testing only - key would be inside the APK!
            return run_ai(kind, payload, GEMINI_API_KEY)
        raise ApiError("AI_NOT_CONFIGURED")

    # ---------- AI routine: Gemini plans, deterministic code referees, the app applies ----------
    def plan_dates(self, days=7, today_only=False):
        """The dates to plan + what the AI must respect on each (already-booked blocks, time left today)."""
        now = dt.datetime.now()
        nm = now.hour * 60 + now.minute
        sd = self.prof.get("school_days", [0, 1, 2, 3, 4, 5])
        out = []
        for i in range(1 if today_only else days):
            day = dt.date.today() + dt.timedelta(days=i)
            iso = day.isoformat()
            d = dict(date=iso, weekday=day.strftime("%A"), school=day.weekday() in sd)
            rows = self.db.all("SELECT * FROM routine WHERE date=?", (iso,))
            if i == 0:                                           # today is already running
                d["from"] = hhmm(((nm + 4) // 5) * 5) if nm < 1435 else "23:59"
                d["study_done_min"] = sum(r["end"] - r["start"] for r in rows
                                          if r["done"] and r["category"] in ("study", "revision"))
            keep = [r for r in rows if r["category"] not in ("school", "sleep") and
                    (r["src"] != "ai" or r["done"]) and (i > 0 or r["end"] > nm)]
            if keep:
                d["busy"] = [dict(start=hhmm(r["start"]), end=hhmm(r["end"]), title=r["title"][:40]) for r in keep]
            out.append(d)
        return out

    def gen_routine(self, note="", today_only=False):
        prof = self.ai_profile("routine")           # workout_minutes is only present if fitness is a goal
        prof["dates"] = self.plan_dates(today_only=today_only)
        if note:
            prof["note"] = note[:300]
        lang = self.prof.get("lang", "en")
        prof["reply_language"] = LANG_EN.get(lang, "English") if ("F_" + lang) in _FONTS else "English"
        dates = prof["dates"]

        def work():
            r = self.ai("routine", {"profile": prof})
            days = r.get("days") if isinstance(r, dict) else None
            if not isinstance(days, dict):
                raise ApiError("AI_BAD_JSON", 502)
            clean = {d["date"]: sanitize_items(days.get(d["date"])) for d in dates}     # never trust the network blindly
            if not any(clean.values()):
                raise ApiError("AI_EMPTY", 502)
            return dict(days=clean, summary=str(r.get("summary", ""))[:240],
                        warnings=[str(x)[:120] for x in (r.get("warnings") or [])][:4])

        def ok(r):
            n = self.apply_plan(r, dates)
            self.db.put("plan_info", dict(summary=r["summary"], warnings=r["warnings"], ts=int(time.time())))
            self.sync_bg()
            scr = self.sm.get_screen("routine")
            scr.note_txt = ""
            if self.sm.current != "routine":
                self.go("routine")
            else:
                scr.refresh()
            self.toast("Routine updated by AI (%d tasks)" % n)
        self.bg(work, ok)

    def apply_plan(self, plan, dates):
        """Replace the AI's own not-done tasks for these dates; manual tasks and finished tasks stay."""
        nm = dt.datetime.now().hour * 60 + dt.datetime.now().minute
        old, new = [], []
        for i, d in enumerate(dates):
            iso = d["date"]
            if d.get("from") is not None:                         # today: only what is still ahead
                rows = self.db.all("SELECT * FROM routine WHERE date=? AND src='ai' AND done=0 AND end>?", (iso, nm))
            else:
                rows = self.db.all("SELECT * FROM routine WHERE date=? AND src='ai' AND done=0", (iso,))
            for r in rows:
                self.db.ex("DELETE FROM routine WHERE id=?", (r["id"],))
            old += rows
            for it in plan["days"].get(iso, []):
                if it["category"] in ("school", "sleep") and self.db.one(
                        "SELECT 1 FROM routine WHERE date=? AND category=?", (iso, it["category"])):
                    continue
                cur = self.db.ex("INSERT INTO routine(date,start,end,title,category,subject,note,src) "
                                 "VALUES(?,?,?,?,?,?,?,'ai')", (iso, it["start"], it["end"], it["title"],
                                                                 it["category"], it["subject"], it["note"]))
                new.append(cur.lastrowid)
        self.db.put("undo_plan", dict(old=old, new=new))
        self.db.touch()
        return len(new)

    def undo_plan(self, screen):
        u = self.db.get("undo_plan")
        if not u:
            return
        for rid in u.get("new", []):
            self.db.ex("DELETE FROM routine WHERE id=? AND done=0", (rid,))
        for r in u.get("old", []):
            self.db.ex("INSERT INTO routine(date,start,end,title,category,subject,note,done,src) "
                       "VALUES(?,?,?,?,?,?,?,?,?)", (r["date"], r["start"], r["end"], r["title"], r["category"],
                                                     r["subject"], r["note"], r["done"], r["src"]))
        self.db.put("undo_plan", None)
        self.db.put("plan_info", None)
        self.db.touch()
        self.sync_bg()
        self.toast("Previous routine restored")
        screen.refresh()

    # ---------- payments ----------
    def start_payment(self, kind, ref, desc, screen):
        if not BACKEND_URL:
            return self.toast("Payments are not available yet.")

        def work():
            return http_json("POST", BACKEND_URL + "/pay/create-link", {"kind": kind, "ref": ref, "desc": desc},
                             {"Authorization": "Bearer " + self.ensure_token()})

        def ok(r):
            open_url(r["url"])
            self.dialog("Complete payment", [L("Pay Rs. %d in the browser (UPI / card / netbanking). "
                                               "Then come back and check status." % r["amount"], 13, "sub")],
                        [("Check payment status", lambda: self.check_pay(r["id"], screen) or False, "grad"),
                         ("Close", None, "ghost")])
        self.bg(work, ok)

    def check_pay(self, pid, screen):
        def work():
            return http_json("POST", BACKEND_URL + "/pay/status", {"id": pid},
                             {"Authorization": "Bearer " + self.ensure_token()})

        def ok(r):
            if r.get("paid"):
                self.db.ex("INSERT OR IGNORE INTO purchases(kind,ref,amount,pay_id,ts) VALUES(?,?,?,?,?)",
                           (r["kind"], r["ref"], r["amount"], pid, int(time.time())))
                self.db.touch()
                self.toast("Payment verified. Thank you!")
                screen.refresh()
            else:
                self.toast("Payment not completed yet")
        self.bg(work, ok)

    def restore_purchases(self, screen):
        if not BACKEND_URL:
            return self.toast("Purchases are not available yet.")

        def ok(r):
            for p in r.get("items", []):
                self.db.ex("INSERT OR IGNORE INTO purchases(kind,ref,amount,pay_id,ts) VALUES(?,?,?,?,?)",
                           (p["kind"], p["ref"], p["amount"], p["id"], int(time.time())))
            self.toast("Purchases restored")
            screen.refresh()
        self.bg(lambda: http_json("GET", BACKEND_URL + "/pay/my", headers={"Authorization": "Bearer " + self.ensure_token()}), ok)

    # ---------- reminders ----------
    def notify(self, cat, title, body, key):
        cur = self.db.ex("INSERT OR IGNORE INTO notif(ts,cat,title,body,nkey) VALUES(?,?,?,?,?)",
                         (int(time.time()), cat, title, body, key))
        if cur.rowcount:                      # unique key -> never duplicates
            try:
                from plyer import notification
                notification.notify(title=title, message=body, app_name=APP_NAME)
            except Exception:
                self.toast(title + " - " + body)

    def tick(self, *_):
        # NOTE: this runs while the app process is alive. For alarms that fire even when the app is
        # closed, schedule Android AlarmManager / WorkManager through pyjnius (needs a small Java
        # receiver service in buildozer). Duplicate protection + timezone changes are handled here
        # because every check uses the phone's current local time and a unique key per reminder.
        if not self.prof.get("setup_done") or not self.settings.get("remind"):
            return
        now = dt.datetime.now()
        nm = now.hour * 60 + now.minute
        qf, qt = parse_time(self.settings["quiet_from"]), parse_time(self.settings["quiet_to"])
        if qf is not None and qt is not None and ((qf <= nm or nm < qt) if qf > qt else (qf <= nm < qt)):
            return
        cats = self.settings["cats"]
        today = now.date().isoformat()
        for r in self.routine_for(now.date()):
            c = NOTIFY_CAT.get(r["category"])
            if r["start"] == nm and not r["done"] and c and cats.get(c, True):
                self.notify(c, r["title"], "Starting now (%s)" % fmt_min(r["start"]), "r%d-%s" % (r["id"], today))
        wake, sl = parse_time(self.prof.get("wake")), parse_time(self.prof.get("sleep"))
        ev = int(self.settings.get("water_every", 90))
        if cats.get("Water", True) and wake is not None and sl is not None and wake < nm < sl and (nm - wake) % ev == 0:
            self.notify("Diet", "Time to drink water", "Stay hydrated", "w-%s-%d" % (today, nm))
        if cats.get("Bedtime", True) and sl is not None and nm == (sl - 30) % 1440:
            self.notify("Fitness", "Wind down", "Bedtime in 30 minutes", "b-" + today)


if __name__ == "__main__":
    StudyFitApp().run()

# =====================================================================
#  buildozer.spec  (copy these lines into your generated buildozer.spec)
# =====================================================================
# [app]
# title = Study Fit
# package.name = studyfit
# package.domain = com.yourname
# source.dir = .
# source.include_exts = py,png,jpg,jpeg,ttf,json
# version = 1.0.0
# requirements = python3,kivy==2.3.0,plyer,certifi,pyjnius,android,sqlite3,openssl
# icon.filename = assets/icon.png
# presplash.filename = assets/presplash.png
# orientation = portrait
# android.permissions = INTERNET,POST_NOTIFICATIONS,VIBRATE
# android.api = 34
# android.minapi = 24
# android.archs = arm64-v8a, armeabi-v7a
#
# Build (Linux / WSL):   pip install buildozer cython ;  buildozer -v android debug
#
# SERVER:  pip install fastapi uvicorn firebase_admin
#          export GEMINI_API_KEY=... FIREBASE_API_KEY=... RAZORPAY_KEY_ID=... RAZORPAY_KEY_SECRET=...
#          export RAZORPAY_WEBHOOK_SECRET=... PUBLIC_BASE_URL=https://your-server
#          python main.py --server        (deploy on Render / Railway / VPS, use HTTPS)
#          Razorpay webhook URL: https://your-server/pay/webhook   (event: payment_link.paid)
# =====================================================================
