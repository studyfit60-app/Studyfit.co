# Study Fit
Python + Kivy Android app (single file `main.py`) with a FastAPI backend in the same file.

- Build APK: GitHub > Actions > "Build Study Fit APK" > Run workflow. Add repo secret `GEMINI_API_KEY` first.
- Server: `pip install -r requirements.txt` then `python main.py --server`.
